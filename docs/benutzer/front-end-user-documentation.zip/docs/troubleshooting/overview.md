# Troubleshooting

* The demo version won’t start.

```The demo version tries to download a embedded Mongo Database. You need to have an active internet connection. You can also check the log files for errors.```

* While starting the demo version an error similar to this occurred

```ERROR d.f.e.process.runtime.Starter prepare : prepare executable
java.io.IOException: Could not open inputStream for https://fastdl.mongodb.org/osx/mongodb-osx-x86_64-3.5.5.tgz
```
Solution: The application was not able to download the mongodb files. You can download those manually. Please see [Installation](../installation/installation.md)

* Where are the log files?

```The default log file directory, is named ’log’ and the folder should be next to your twx-Analyzer Jar-file.```

