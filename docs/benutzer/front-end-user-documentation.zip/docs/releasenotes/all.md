# Release Notes

In future releases, we will publish all release notes here.

!!! important "Latest Release 3.0.4"

## Release 3.0.4

* TA-526 (TWXASD-80) : Exceeded limit on max bytes to buffer - weitere Fixes
* TA-513 : Timeout 180s unter Openshift an Route und Service nun immer gesetzt

## Release 3.0.3

* TA-526 (TWXASD-80) : Exceeded limit on max bytes to buffer
* TA-524 : Update [documentation swagger-ui](../installation/rest-api.md) usage and configuration

## Release 3.0.2

* TA-525 (TWXASD-79) : Configurable timeout for backend urls

## Release 3.0.1

* TA-520 : Moved entirely to new BAW/BAS API
* TWXASD-76 : URL Pfad für BAW REST API (Cloud) "basops"

## Release 3.0.0

Helm

    * Helm Chart delivery via Artifactory (TA-342)
    * Customer Logo delivery via HelmChart (TA-514 & TA-508)
    * Theme control via Helm-Chart (TA-480)
    * Helm chart prerequisites documentation enhancements (TA-515)

Backend

    * OpenApi UI for CI/CD (TA-502)
    * Technical BAW admins are configured through helm (TA-462)
    * Introducing a tenant mode (TA-477)
    * Update to Spring Boot 3 & security fixes (TA-343)
    * Update to MongoDB 8.0.1 (TA-492)
    * Preview version of the plugin with input variable type mismatch. Limited cases (TA-517)

Frontend

    * Update to Angular 15 & security fixes (TA-406)
    * Process App Acronym is now part of the "Active-View" element (TA-447)
    * Changes to diff running symbol (TA-449)
    * Configure the BAW URL for cloud installations (TA-507)

---
## Older Releases

### Release 2.3.9

* TA-493 | TWXASD-75: Bug filter in "Analyze By Service" dropdown does not work

### Release 2.3.8

* TA-417 | The backend must be able to respond to a changed plugin list

* TA-416 | Manage the list of installed plugins via Helm Chart

* TA-462 | The technical user for BAW is configured via Helm.
    * Note: Can still be changed via frontend. This will no longer be supported in the future.

* TA-463 | The Helm Chart will be delivered via Artifactory in the future: https://twxsolutions.jfrog.io/artifactory/twx-analyzer-helm-local/twx-analyzer-2.3.8.tgz

### Release 2.3.7


* TA-103 | Plugin for Process App or Toolkit assignment will no longer be deleted when the last snapshot of a ProcessApp is deleted.

* TA-107 | Report similar object names as errors.
    * Search for data types that are very similar in name. For example, through multiple "Discovering" of SoapService interfaces (WSDLs), identical or slightly different (Name2) object names can always arise. The search spans the ProcessApp and all toolkits except the SystemToolkits.

* TA-114 | Removal of Material Design elements.

* TA-179 | Toolkit conflict results are no longer displayed when the corresponding plugin is disabled in the assignment of Process Apps or Toolkits.

* TA-325 | Introduction of a new function to determine unreferenced (Orphan) Toolkits. This function helps with the cleanup and management of toolkits.

* TA-392 | Improvements to the plugin for Process App or Toolkit assignment:
  
    * Added column click functionality to optimize the user experience.
    * Performance optimizations made, especially with many entries, to ensure faster processing.

* TA-447 | Correction of an error where the Process Acronym was missing in the active snapshot display. This adjustment ensures that all relevant information is displayed correctly.

* TA-448 | Fixing an error that occurred when no selection was made during automatic download.

* TA-449 | Adjustment of the symbol for "running" in the Diff-History area to make the visualization of the status clearer and more intuitive.

* TA-471 | Update of XML parsing and adjustment to the new BAW version. This change improves compatibility and reliability in processing XML data.


### Release 2.3.5|6

* TA-423 | Permanently ignore findings via the frontend

* TA-442 | Limit the number of snapshot history entries

* TA-406 | Library updates + security fixes

### Release 2.3.4 and before

Please ask you administrator for previous release notes.

