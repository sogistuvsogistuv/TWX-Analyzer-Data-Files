Hallo,


I am looking for a java developer who is very familiar with xml (xmlBeans, xjc, ...). What I want to achieve is a Java Programm/library that takes a bunch of Schema files as input and creates Java classes for these schemas. Preferably done with/in a maven project and via certain maven Plugins (listet below). If there is no fitting maven module other options are possible. As a result a java library file is needed, since it will be used in a another tool.

Know to me are these tools/ or maven Plugins:

xmlBeans, xjc

I need to mention, that these xsd files are created from a bunch of xml files. In case there are issues with the xsd files please let me know and we will discuss the tool that creates the files. But it is important to me that these files are valid so that the generated java code is correct.

Below I will list a few of these xsd files as well as 