# Mandantenfähigkeit bzw. mehrere ProcessApps bedienen

## Problembeschreibung
Für eine Cloud implementierung benötige ich ein Login Funktionaltität. Da ich aber gleich aber gleichzeitig auch onPremise ohne login arbeiten möchte, muss die "security" zum Beispiel über das Profil oder eine andere Einstellung steuerbar sein. Dazu gehört natürlich dass diese sowohl in Angular, als auch in der security von Spring boot auswirkungen hat.

Für Angular würde zum Beispiel alles rund um Login und Logout nicht angezeigt.  

Es gibt zwei Einsatzszenarien für den Twx-Anayzer: OnPremise und Cloud. Das Cloundangebot gibt es momentan noch nicht, sollte aber bei den Überlegungen einbezogen werden. Beide Installationsarten haben unterschiedliche Anforderung an die "Mandantenfähigkeit". Ein Cloudangebot benötigt einen sicheren Login, während die OnPremise Variante den User möglichst schnell an sein Ziel bringen sollte. 

## Lösungsideen

?? 


### Links:
[real-time-examples-for-oauth2-grant-types-and-good-document-example-for-oauth2nk](https://stackoverflow.com/questions/27056428/real-time-examples-for-oauth2-grant-types-and-good-document-example-for-oauth2)


[angular-6-user-registration-and-login-example-tutorial](http://jasonwatmore.com/post/2018/05/16/angular-6-user-registration-and-login-example-tutorial)

[tut-spring-security-and-angular-js](https://github.com/spring-guides/tut-spring-security-and-angular-js)

[-boot-spring-security-jwt-mysql-react-app-part-1](https://www.callicoder.com/spring-boot-spring-security-jwt-mysql-react-app-part-1/)

[spring-boot-oauth2-jwt-example](https://www.devglan.com/spring-security/spring-boot-oauth2-jwt-example)

Serie:

https://www.baeldung.com/rest-api-spring-oauth2-angularjs

https://www.baeldung.com/spring-security-oauth2-refresh-token-angular-js

https://www.baeldung.com/spring-security-oauth-jwt

