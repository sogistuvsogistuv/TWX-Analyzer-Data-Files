# Userstory 04 - Service Repository

Diese Funktionalitaet soll dabei helfen einen besseren Über-/Einblick in die Services zu bekommen und durch kleine Service bezogene Tools Unterstützung bei der Implementierung leisten.

## Funktionen

Als Entwickler möchte ich nach einem Service suchen können und Informationen und Tools nutzen, die der ProcessDesigner nicht bietet.

### Service Komplexitaet

* Service Usage: Wie oft wird der Service verwendet + Auflistung der Services die, den aktuellen Service verwenden.
* Service Elements: Wie viele unterschiedliche Elemente wie Coaches, Scripts, Service, ... verwendet der Service und wie heißen diese
* Service Depth: Wie viele Ebenen ruft der Service auf. Gibt einen Wert für die Komplexität

### Basis Info

* Lines of Code fuer den gesamten Service
* Fehler im Service ggf. inkl. Unterservices?
* Groesse in KB des Service

### sonstige

* Logging Creator: Tool um aus den In-/Output Variablen das Start und Ende-logging zu erstellen
* Doku Creator: Tool um die Dokumentationvorlage fuer Services (Docu tab) zu erstellen
* Doku Export: Dokumentation exportieren fuer einzelne Services - Export to PDF

Multiselect taggen – Rest Api
Tag Sortierung – Tag wollte – Tag Suche – TagGroup Suche
Tags eines Service