// Globally defined variables are:
name: globalVariable1,  type: boolean
name: someObjectId,     type: String
name: dimensionPairs,   type: DimensionPairs, sample
{
 "id": "1234-ADFA",
 "size": {  // type:
   "width": 5,
   "height": 10
 },
 "name": "A green door",
 "price": 12.5,
 "tags": []
}
type: "Size", consists of variables width and height

/////////////

// Settings values
tw.local.someObjectId = "value";
tw.local.dimensionPairs = new tw.object.DimensionPairs();
tw.local.dimensionPairs.id = "1234-ADFA";
tw.local.dimensionPairs.size = new tw.object.Size();
tw.local.dimensionPairs.size.width = 5;
tw.local.dimensionPairs.size.height = 10;
tw.local.dimensionPairs.tags = new tw.object.listOf.String();
tw.local.dimensionPairs.tags[0] = "tag1";
tw.local.dimensionPairs.tags[1] = "tag2";
tw.local.dimensionPairs.tags.insertIntoList(0, "tag3")
tw.local.dimensionPairs.tags.insertIntoList(tw.local.dimensionPairs.listLength, "tag4");

if(tw.local.someObjectId == null){
    tw.local.globalVariable1 = true;
}

// setze den ausgewählten Sicherungsnehmer
if(!!tw.local.someObjectId){
    for(var i = 0; tw.local.dimensionPairs.tags && i < tw.local.dimensionPairs.tags.listLength; i++ ) {
        if(tw.local.dimensionPairs.tags[i] == "tag3") {
            tw.local.dimensionPairs.tags.listAddSelected(i);  // listAddSelected is a method automatically added to global variables
            // or variables created through new tw.object.xyz()
            break;
        }
    }
}

if(tw.local.dimensionPairs.tags.listLength>0){
    log.info("length is bigger then 0");
}

var tmpMap = new tw.object.Map();
    tmpMap.put("key1", "value");
    tmpMap.put("key2", "value");
}