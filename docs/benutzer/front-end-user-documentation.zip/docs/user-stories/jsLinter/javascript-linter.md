# Linting JavaScript with a Java Programm

I am looking for someone who can create the following code which will be part of a bigger application:

I have a static code analyzer, which targets a relative specific process engine. I would like to enhance my software 
with the capability use a javascript linter, to check javascript code that is written inside the process engine. I think this
is best done by using a existing javaScript linter to analyze the code. My analyzer is build with java 8 and spring boot.
 
Please understand, that I do not want to create a new javaScript linter, I would like to benefit from those which are already existing. 
Additionally, I would like to use the configuration capabilities of the typical javascript linters, like for example in EsLint. 
EsLint is the one I know and think is well suited for that task, but it is not a requirement to use this specific one.
The code that needs to be analyzed is mostly written in javaScript. I would like to analyze that javaScript code with 
an existing javaScript linter like for example "EsLint".  

I am not sure, if this is important, but the javaScript that needs to be analyzed uses ECMA-262. Meaning the linter 
should be able to handle this old java script version. Maybe also of interest is, that to my knowledge the process 
engine uses rhino to interpret the javascript and run in inside the scripts.

## System Details

Figure 1 shows that the javaScript of the process engine is split into different elements. In other words, code can be 
in different places. And that is important since every scriptlet needs to be linted (analyzed) with the new code separately. There for the
code you are going to write should be realatively efficient/fast, because the "linting" of code snippets will be done quite often.

![figure_1](process-picture.png "Figure 1: ...")

When I am coding for the mentioned process engine, for each so called "service" a developers can define global variables. 
Which would be accessible from every step/element (like in figure 1). A service is basically a sequence of 
javascript elements. The squared boxes are script items, which can contain complexer javascript snippets. While in the 
decision element, the content or script would be very short, more like an if statement, which returns a truthy of falsy 
value. Local variables can still be defined in a script element, like in every normal javaScript.  
 
```
    var test = ['some','array'];
```
I will explain what I mean when I speak of "mostly written in javaScript". The "global" (for a service) defined variables
can be of type String, Integer, list of Strings, ... but they can also be of more complexity and even be a list of a complex 
 object. To define an object in this process engine, one has a variable builder, where objects are created. In the small project
 I provided a class called "TODO" which delivers the class hierarchies as json.  
 
A very small sample javascript would look like this (more samples at the bottom):
```
Sample Code
```
As you can see a global variable is addressed by tw.local.{variableName}.{variable attribute}. The globally defined variable 
exists under the namespace "tw.local". So obviously "tw" will have other objects, and yes there are:
1. tw.env
2. tw.object
3. tw.system
4. tw...

All the above tw.env, tw.system, ... are offering a set of methods and variables which can be used to do things in the scriptlet.
So this is stuff outside the normal javascript and one of the difficulties might be that they should not be mentioned by
the linter as errors. In chapter [TODO]{link} I have listed a more or less complete set of these methods and variables. This 
list should easily be editable in the code.

More over, since the javascript is interpreted / executed with the rhino engine you can even use java in the javasnippets.
So you could do something like this:
```
var erfasserEscaped = org.apache.commons.lang.StringEscapeUtils.escapeHtml(tw.local.someText);
```
I do not know yet how one could handle this, cause basicly any class is usable that is available in the engines classpath. 
Any ideas are welcome.


In line x of the sample "jsSample1.js" you can also see how the globally defined variables are instantiated. They seem to be injected into
the code as objects. 
```
var variableInstance = new tw.object.{some object}
//or even a list
var listOfAVariableInstance = new tw.object.listOf.{some object} 
```
 
Also, we have provided a complete list of the predefined ClassTypes / Variable Types from the process engine. Here [TODO] 

variable definition not inside the code snippet.
Also, globally defined scripts can be part of the system. -- Datei hochladen
In the end many little scripts so the code must scale.

## Object creation
So it turns out, that I have access to the xsd representation of all the object Types
```
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:tns="http://SOME" 
xmlns:tns0="http://NAMESPACE" targetNamespace="http://SOME" elementFormDefault="qualified">
  <xs:import namespace="http://NAMESPACE" schemaLocation="Currency.xsd" />
  <xs:complexType name="Receid">
    <xs:sequence>
      <xs:element name="id" minOccurs="0" maxOccurs="1" nillable="false" type="xs:string" />
      <xs:element name="name" minOccurs="0" maxOccurs="1" nillable="false" type="xs:string" />
      <xs:element name="amount" minOccurs="0" maxOccurs="1" nillable="false" type="tns0:Currency" />
    </xs:sequence>
  </xs:complexType>
</xs:schema>
```
With this information one can crate the json object or json schemas to inject into the analysis using a js linter. 

## Details of object definitions


## More sample scripts

### First script
Link file jsSample1.js