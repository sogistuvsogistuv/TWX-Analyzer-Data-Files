-- User story Toolkit Explorer capabilties

# Angular (material) tree implementation enhanced

I need an enhanced implementation of the [angular materials](https://material.angular.io/components/tree/overview) or [cdk](https://material.angular.io/cdk/tree/api) **tree** implementation. The data for the tree is loaded from mongodb through a java spring boot service that provides the endpoints/api. For this job I will provide current code and mock data. 


## Current Tree data and schema
Currently the tree data in the database has this structure:

```
TODO
```

If the JSON structure is not suitable for the below requirements the schema is still changeable.

## Requirements



### Design 


### Behavior

1. Collapse and unfold all items

    For a quick overview of the tree and its data, the user would like to expand all items of the tree. Therefor it should be entirely collapsable aswell.

2. Filter function

    - As a user I often would like to know where in the tree certain elements are located. Therefor a quick filterfunktion is required. Items can occur several times in the tree.
    - The collapse all and unfold all functionality needs to work even if the tree is currently filtered.
    - For now the filter is a simple text input. A typeahead capability is not yet needed, but keep it in mind while developing the code.

3. Possibility to highlight instead of, or in addition to filtering

    - In some cases I simply would like to know where in the tree certain children elements are and if somewhere in the tree are the same elements. For a better overview and quick identification, a highlighting function is needed.
    - The colors for equally named children must be unique.

4. Possibility to klick on an item to get detailed element information

    - Every child (leave, branch, root) shall have a small info icon button, which displays the information data of the item. For the details please check the JSON at the top.

5. Lazy loading of children items

    - Since the amount of children and their children and so forth, the tree depth may become quite huge. So the children should be lazy loaded when the branch is unfolded. Meaning when the branch is opened the data will be read from the database.

7. Tests

    - The final code should contain test cases

--------- ADNVANCED FEATURES ---------

The below section are part of the second milestone.

8. Choose current leave as new root

    - As mentioned earlier, trees might become quite big. A possibility to hide the parent elements or even better making a tree item the new root element is necessary.
    - If the user wants to he can still open the parent elements.
    - With this capability it should also be able to start the tree with any element in the database.

9. 
    
    - Sometimes it is necessary to compare an older version of the tree to the new version. This functionality should display or highlight the differences of two trees.

10. Recognize circular dependencies

    - The data may contain circular dependencies. So before a user opens the same combination over and over he should be warned. Also a circulation could step over several until the repition occurs.

11. Update Pfad berechnen