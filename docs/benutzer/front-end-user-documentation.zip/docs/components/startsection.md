## Snapshots

The snapshot overview is a central piece to manage analyzed snapshots in the twx-Analyzer. It lists all snapshots which have been analyzed in the past and highlights the current activated snapshot.

The context menu in the left row provides additional capabilities such as:

* Delete - Delete the snapshot
* Reanalyze - In case new plugins were introduced or configuration has changed you can reanalyze the snapsot.
* Autoload - To have the twx-Analyzer connect to BAW and check for a newer version.

## Upload

This is where exported snapshots can be uploaded and analyzed. By dropping the file into the green area, the file is automatically uploaded to the twx-Analyzer server. After that it is ready for inspection, the analyze button will be clickable.

An alternative to manually uploading files, is to connect the twx-Analyzer (see section: [Settings](./settings.md)) to your BAW server. This enables the possibility to have the analyzer taking care of downloading and starting the analysis. Users will be notified as soon as the analysis has finished.
