This section holds the system settings and plugin overview section. For more detailed information on configuring the system, please check out the [configuration documentation](../installation/configuration.md)

## System

### General settings

#### System Settings

##### Server configuration

* Enables remote download: You can download snapshots from Process Center via frontend
* BPM hostname: Hostname of the process center

##### BPM credentials

* Activate download via WebClient-Infrastruture: Do not change, this is the new default and faster approach for downloading files
* Activate download via new BAW-API: Download of twx-Files will happen via the new BAW-API. ATTENTION: This feature will only work if WebClient-Usage is enabled!

TODO Tenant Konfiguration und Erklärung + Rest Calls

##### Plugin settings

* Plugin folder: This is the folder where all plugins are located
* BPM hostname: Hostname of the process center
* Protocol: You should always use HTTPS
* Port: HTTPS Port of the ProcessCenter

##### Snapshot Diff

This is a list of Tags or Nodes that will be removed from XML and therefor not be part of the diff. 
You can use XPATH to address new tags, nodes or even attribute. For example this ```inputPort/@id``` will remove the 
id-attribute from the inputPort node. An this would remove the id-tag below layoutItem ```layoutItem/id```. 

The default list is:
  - lastModified
  - lastModifiedBy
  - modificationDate
  - versionId
  - guid
  - jsonData
  - parameterMappingId
  - parameterMappingParentId
  - bpdParameterId
  - tWComponentId
  - bpdEventId
  - faultParameterId
  - switchConditionId
  - endStateId
  - outputPort/@id
  - inputPort/@id
  - defaultInstanceUI/@id
  - ownerTeamInstanceUI/@id
  - expression/@id
  - condition/@id
  - inputPort/@id
  - outputPort/@id
  - assignment/@id
  - inputSet/@id
  - outputSet/@id
  - laneFilter/@id
  - htmlHeaderTag/@id
  - formTask/@id
  - teamFilter/@id
  - EventAction/@id
  - EventActionImplementation/@id
  - inputActivityParameterMapping/@id
  - extension/@id
  - coachEventBinding/@id
  - artifactReference/@id
  - nameValuePair/@id
  - layoutItem/id
  - configData/id
  - contentBoxContrib/id

##### Others

* Keep snapshot files [Default: true] : Snapshots are stored in the database after download.
* Activate fulltext search [Default: true]: Toggle for the fulltext search feature.
* Snapshot History [Default: 2]: The amount of snapshots which are kept when a new analysis for this ProcessApp (and Track) will be performed.

As a result of the Download Service revamp and improvement, there are now two new configuration parameters in the backend:
- Activate download via WebClient-Infrastructure: determines whether new Download Service classes should be used (true) or the old implementation (false). 
- Activate download via new Baw-Api: determines whether the new Download API should be used (true) or the old one (false). (This parameter only has an effect when 'Activate download via WebClient-Infrastructure' is set to true, as only the new Download implementation supports the new Download API.)

If you need to setup certificates in order to get connection to the process center, navigate to [configuarion](../installation/configuration.md).

#### Plugin settings

Every plugin may define a set of configurations, this is where these configuration are collected.

#### Theme settings

You can change your theme here

The default theme is set via the helm chart configuration. Also the logo is now configured during helm installation.
For more information checkout [Helm installation](../installation/overview.md#helm-installation)

## Plugins

In this section it is possible to configure which toolkits are used for which process app. First you need to choose a process app.

![Select process app](../pictures/plugin_select_processapp.png)

Only process apps, of which a snapshot is already analyzed can be selected.

The rows are devided into three colors, which match the colors of error, warning and bad style findings.
In the header row and first column, the green plus icon allows to add toolkits which are part of the selected process app. Afterwards you can choose which findingType shall be applied to the toolkit.

![Fine grained findingtype configuration](../pictures/plugin_toolkitselection.png)

## Tenant

In the latest version of twx-Analyzer, the concept of a tenant was introduced.
A tenant is a logical entity that represents a project (Process App) or a group of users. 
The tenant concept is used to separate data and configurations between different projects. 
This is useful when you have multiple projects using the same twx-Analyzer instance and process center. 
The tenant concept allows to separate the data and configurations of each project or even a group of project. This way, you can ensure that the data and configurations of one customer are not visible to another customer.

The tenant configuration is done via environment variable and is controllable in the helm chart.

### Configuration
Two things are important to configure in order to use and activate the tenant feature:
1. Activate the tenant feature in the helm chart
2. Configure an administrative user that is allowed to create and manage tenants via the REST API

The following environment variables are used to configure the tenant feature in the analyzer/deployment.yaml file:
- \`name\`: \`SYSTEM_TENANT_API_USERNAME\`
  \`value\`: \`user01\`
- \`name\`: \`SYSTEM_TENANT_MODE_ACTIVE\`
  \`value\`: \`true\`

!!! important "activate process center connection"
    It is very important (requirement) to activate the process center connection. When working with ids, the twx-Analyzer
    may need to call the process center to get the acronym for a specific id. This is done via the REST API to the process center.

### Tenant Rest API

This is the **current** OpenApi specification yaml-file: [spec for tenant configuration (yaml-File)](./openapi_tenants_v3.0.0.yaml).

### Limitations

If a user is assigned to more then one tenant, he is considered a part of the first tenant of the potential tenants. 
In other words a user can only be part of one tenant at a time.