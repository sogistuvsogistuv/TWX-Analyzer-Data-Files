## Findingtypes
Findingtypes categorize the findings by severity. A Plugin can "deliver" several findingtypes of different categories.
These categories indicate how healthy in terms of clean code a snapshot is and if a deployment of those snapshots is advisable.

Categories:

* Error: They most likely create exceptions during runtime. This is the most critical category.
* Warning: Can be findings, that decrease performance or are violations of the coding guidelines.
* Bad Style: Indicate that some code is not following the basic styling rules or are violations of specific coding guidelines.
* Others: Findings created by plugins that do not fit into a specific category. Such can be: A list of all services of type ’rules’.

Each category consists of a list of possible findingtypes. The numbers in figure 1 indicates how many of those findings occurred in the current snapshot. The below pictures contains a list of all findingtypes of severity error, for a snapshot. Details appear by clicking the chip elements. As a result all findings are listed like in figure 1.

![figure_1](../pictures/Error.png "Figure 1: Error findings")

Services and processes can contain multiple findings of different plugins. For this situation a
service overview page is available, which lists findings of every category. This page also contains
the possibility to search for servicenames or processes. In figure 2 it is the ’By Service’ link in
the upper right corner with the green icon.

![figure_2](../pictures/ByServiceFilter.png "Figure 2: By Service")

<!-- TODO exclude erwaehnen -->
### Exclude services

To exclude services from all or certain findings types, create a tagGroup in BPM named 'twxAnalyzerIgnores' and add tags that carry the name of a findingtype. By adding the tag of this tagGroup to a service, the service will be excluded from the analysis. To ignore all findings at once, you can use the tag 'All'.

## Findings

These are the analysis results and belong to a findingtype. If a finding is found in a toolkit, behind the service name there will be a small ^TK^, which indicates that the source of the finding is a toolkit. Hovering over the short text will show a tooltip containing the name of the toolkit acronym.

### Ignored Findings

As mentioned before you can exclude entire services from the finding result list with a [tagGroup](analyze.md#exclude-services). 
You can also ignore a specific finding. Go to Error/Warning/Bad Style and choose a findingType and then select the finding 
that shall be ignored. 

More details: 
Since the analysis of a ProcessApp cannot distinguish which analyzed service is actually relevant and which, for example, 
was built for a quick "service test" and therefor may contain errors. The goal, of course, would be to avoid receiving findings of this 
nature or other undesirable findings reported as errors again and again in each analysis.

If a finding is not desired and should not be included in subsequent analyses and therefore in new snapshots, 
it can be marked in the frontend after an analysis. When the page is then refreshed, the finding will no longer be displayed, 
and even in a completely new analysis of the current or a new snapshot of this app, the finding will not be reported again.

In other words, the finding will be ignored until the ignore setting is revoked. 
Even a analysis of a newer or older snapshot will not show findings which match the that has been chosen to ignore. For more
information how many snapshots are preserved when new a snaphot is analyzed check the [configuration settings](./settings.md#others). 

An overview of findings marked as "Ignore" can be found at Analysis -> Ignored Findings . However, 
this will also display findings or findings to be ignored that may already be fixed or not available in the current 
snapshot for other reasons.

Even in a CI/CD call, no findings which are to be ignored are provided.