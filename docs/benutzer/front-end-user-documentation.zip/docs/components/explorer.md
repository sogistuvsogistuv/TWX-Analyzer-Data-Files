This section thrives to give a deeper insight into the snapshot. It contains functionality
like a toolkit hierarchy tree, as well as list of all services.

* **Toolkit Explorer**: Contains a tree representation of the used toolkits.
* **Environment Vars**: It is difficult to get an overview of all environment variables, especially if their toolkits which contain environment variable definitions.
* **System Repository**: Better insight into services or processes, as well as their variables and documentation. This tool also provides a wide range of additional capabilities, such as generating code, which is good practices compliant.
* **Snapshot Diffs**: Compare two snapshots for increment or change identification.
* **Orphan Admin**: Show all orphan toolkits and their state for manual archiving or deletion.

### Details - Snapshot Diffs

This tool offers the possibility to compare snapshots created in the ProcessCenter with each other. The backend server creates a Git repository, 
which is filled with the two snapshots (base and commit). 
The base snapshot goes into the first initial commit and the second snapshot (called: commit snapshot) into the second commit.
Afterwards a standard Git-Diff command is executed with the tooling "jgit". The result is transferred as a unified string to the frontend
which generates a well readable representation.

First we do remove all the XML-files that belong to System Toolkits, that does speed up the calculation and those are not needed in the comparison since
you should never ever make manual changes to these toolkits. But please let us know if you have other requirements.
Then, to make the BAWs (not always valid) XML documents (partly multiple XML declarations) valid, readable and processable each file has to undergo a
cleaning process (called "makeValidXml"). Afterwards certain tags are removed ([tag list configuration](../components/settings.md#snapshot-diff)), then for 
the comparison reasons the XML is stripped of its namespaces, before the server performs character unescaping, and finally sorts certain tags based on their UUIDs.
At last, the XML is turned into a nice form (pretty-print).
These steps are necessary on the one hand to make the XML processable at all and then to get as few wrong differences as possible when creating the Git-Diff.

If two snapshots of different process apps are selected, the system asks if this is really wanted, 
because this can lead to very long calculation times and differences. Such a difference can contain up to 20MB of data.
And of course the more changes between two snapshots the bigger the differences and there this has direct impact to the frontend. 
The unified diff string has to be interpreted into HTML and this can lead to a lot of additional HTML-tags. This has to be kept in 
mind also when a historic snapshot is selected.

It is possible to select the same snapshot for base and commit, but the system will ask if this is really intended.

Currently, a connection to the BAW server is required when selecting snapshots. If this configuration is not active, no comparison can take place,
because the snapshots cannot be downloaded. In addition, the snapshots must be configured to be saved to MongoDB after downloading.
If this is not active, no processing can take place either. Among other things files are required to avoid having to call the BAW server again when comparing snapshots.

Once generated, comparisons are stored in the database and referenced when run again. They are also accessible via the history tab.

In the course of generating the comparison, the files available as <UUID>.xml are renamed to make them easier for 
the user to read. Unfortunately, IBM BAW allows special characters in the names of the services, BPDs, etc.. which are not allowed in Unix or Windows as file names.
For this reason all characters these characters: `<>:"/\|?*` are replaced by an underscore. 
Then there are cases when IBM does not provide a name for the xml files, that's the reason you may see UUIDs in the diff.

!!! note
    Currently, it is not possible to select Toolkits for comparison. In this case you have to wait for manual upload feature.

!!! important "Two snapshot versions in a ProcessApp"
    If you compare a Snapshot that has, in its toolkit-dependency-tree, two different versions of the same Tookit referenced, then 
    unexpected results may appear. The reason is, that the toolkit is extracted in a folder named like the toolkit project name 
    and if there are two versions of the same toolkit, then files may be overwritten and the order is not controllable. For now,
    you need to analyze the snapshot and check with the ```Toolkit Conflict``` plugin.

!!! important "File links"
    Currently the comparison view has a clickable link on the file list, but unfortunately that link is not working. We are trying
    to find a workaround. Be careful with a click it reloads the page and you would have to recall your comparison from the history tab.

#### Elements of the tool

Next to the button to start the comparison there is a checkbox "Sort Tags". Since the sorting takes a lot of time, this gives the user the possibility to switch sorting off.
However, this leads to the fact that the result is sometimes more difficult to read, because the order of the tags in the XML files
makes for more differences that are actually not differences at all (false positives).
It should also be noted that an analysis previously performed with a different "Sort" status must be run again with the changed flag to incorporate this change into the result.

As mentioned, tags are also removed when processing the XML files. These tags usually contain UUIDs, which
often change for unknown reasons and thus create many uninteresting differences. In principle
any tag can be removed with this configuration. The list can be found in the [configuration section](../components/settings.md#snapshot-diff) of the application and
should be customized with care. Also, sorting Tags often needs the UUID of those tags, so we recommend customizing it in coordination with us.

The history view contains all non-sorted comparison requests of the past. In this view you can delete any entry or administer long-running and
potentially never finished request. If such request takes longer then 30 minutes a button occurs which allows you to mark the comparison as
finished.
By double-clicking on a row the view switches to the other tab a displays the selected results.

#### Diff UI

The configuration or filter values for the diff-ui are stored in the local browser storage. Therefor changes
are saved until the browser is reset. It is a temporary saving mechanism and has no effect for other users.

To control how results are presented you have some options. 
* Output format: choose between inline or side by side view. Default value is inline (line by line).
* File summary: The list and overview on the files that change can be toggled with this checkbox. The default value is true.
* Matching type: Matching level: 'lines' for matching lines, 'words' for matching lines and words or 'none', default is none
* Max. line length for highlighting: A difference may contain multiple differences even on the same line, determined by
  the number of characters in a line, if this threshold is exceeded, the differences per line will not be highlighted. 
  The default value is 100. 
* Max. line length to display: A difference may encompass multiple lines, determined by the number
  of characters in the longest line, if this threshold is exceeded, it would conceal the diff.
  Remember: longest line is taking precedence. The default value is 150.
* Max. changes to display: A difference may encompass multiple changes, determined by the number
  of changes, if this threshold is exceeded, it would conceal the diff. The default value is 120.

Other options can be included if necessary.

As mentioned before the UI has an issue with the click on a filename, that leads to a page reload.

Besides that, your viewed files are not stored in database, meaning if you reload the page those checkboxes are unmarked.

Also keep in mind that IBM sometimes has no name for the xml files. That is especially the case for SubProcesses, 
which leads to an ID as filename instead of a readable and  allocatable entry.


#### Performance

We are aware that storing the data on the file system is not yet an optimal solution and can be a bottleneck for performance.  
We will keep introducing optimizations here. But also for this reason we recommend not to run more than one or two comparisons at a time as this will affect performance.The frontend has a display or infobox that shows, if an analysis is already running. 
An analysis for two identical snapshots cannot be not be run twice.

Also the frontend creates a lot of HTML-tags therefor depending on your computer and the amount of differences, this 
could take some time. 

#### Further development

The aforementioned manual upload will be provided in subsequent versions.

The sorting of objects puts a heavy load on processing, so we were initially very conservative with the list
of tags to be sorted. However, extensions can be made at any time.

#### Troubleshooting

###### MongoDB Exceptions

Should exceptions of this kind occur:
 `org.bson.BsonMaximumSizeExceededException: Payload document size is larger than maximum of 16793600.`
Thus, due to the size of the results, the default configuration of MongoDB must be adjusted.
In this case MongoDB tries to store data larger than 16MB.


### Detail - Orphan Admin:

This tool displays the list of all orphan Toolkit snapshots or even Toolkits in the configured IBM BAW server. 
You have to have a connection to your BAW server configured. You can do this by enabling remote downloads ([settings](./settings.md#server-configuration)). 

In release 2.3.1 it is not yet possible to archive or delete the snapshots in this tool. It has to be done manually, but this at least
gives you the information which snapshots could be archived or deleted.
To delete an orphan toolkit snapshot, it must first be archived. If a snapshot is orphan an already archived, so ready for deletion,
it is shown by a tag behind the snapshot name.