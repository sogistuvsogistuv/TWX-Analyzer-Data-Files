# Overview

<!-- TODO auch bei capabilities auf der welcome page -->
Plugins create the analysis result and deliver so called ’findings’, which indicate that some code
or configuration disobeys a certain rule and therefor a developer should attend to and change
it. But the twx-Analyzer also delivers tools and functionality for other tasks and questions,
that come in handy when developing with IBM BPM. The following sections explain the basic
capabilities.



## [Start](startsection.md)

This section is the tool to manage, upload and analyze snapshots. It is the control center for
snapshots.

* Snapshots: Lists all analysed snapshots and shows the current activated snapshot.

* Upload: You can upload and start analysis of BAW and ISF files.

## [Analyze](analyze.md)

List the findings of the currently selected snapshot in different categories.

## [Develop](developer.md)

There you can find tools which are helpful for the day to day development tasks.

## [Explore](explorer.md)

It contains tools for a better overview into a snapshot and contains search functionalities.

## [Settings](settings.md)

The system and plugin configuration is editable in this section. It also contains the overviews off available plugins.