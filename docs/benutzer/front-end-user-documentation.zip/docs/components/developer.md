Contains helper functionality for developers, as well as some tools for deeper analysis of the structure of a snapshot.
It is very important to know which elements and how elements are used in the snapshot or if there are unfinished tasks.

* ServiceNaming: A good practice is to name exceptions uniquely and similar to service where they are possibly thrown.
  Please see [best practice](../bestpractices/all.md). This tool creates the ExceptionEventNames out of the services
  name. If developers decide to follow this rule there is a plugin, that creates findings if an ExceptionEventName does
  not match.


* Field Refs: Certain projects have recurring name patterns, or one needs to find all occurrences of a certain text.
  This is where the system shows all search results for such demands. The search patterns are regular expressions, which
  are configured in the settings section.

<!-- * Loggernames: Fine granular control of logging can come in handy. The analyzer delivers
functions and best practice for a logging approach. If this approach is used, the logger
names are listed in this section. Please see Appendix A ’Appendix’ : for detailed description
and howto.
-->

* Resources: Dealing with localization in large projects can be difficult. In here all available localization variables
  are listed. It is more convenient to search in this tool and look for already available text, then in the process
  designer. The listing contains also shows how many times a certain variables is used in the code.


* Todos: Lists all places where a developer has placed a todo. By adding some keywords to the TODO, the system can even
  recognize for whom the item is created and when it was created. The current expression how a TODO is defined is:

  TODO [ from ] origin_name [ to receiver_name ] date ( DD.MM.YYYY ): text


* Search: This is the first version of a full text search. The search is available for 5 different types of elements [bpd services (process), epv, coach views, objects (twClass)]. In the result table a list of elements are visible. By choosing one the content of that element is presented as a json tree on the right hand side. For more details see below description.  

### Details - Field references

Basically the field references are the first step towards a full text search. Like previously mentioned, it uses regular
expressions to find matches of these expressions. The search will be performed at all places where code, documentation, notes or names can be or are specified. The configuration of the list can be done in the following section:
Settings -> Plugin settings -> "Fieldrefence search variables". To add a new entry to the list
the text field must be filled with a valid regular expression. Afterwards the value
is confirmed with "Enter" and finally transferred to the database by clicking the "Submit" button. Changes to the list, such as
for example, adding or removing an entries, without subsequent saving via the Submit button are not persisted permanently.

Currently it is not checked if the entry is a valid regular expression, in this respect special care has to be taken that the entries are correct.

If an ISF (APPX) file is analyzed with the twx-analyzer, the object/app namespaces are automatically added to this list. This allows to search in the ISF app as well as in the BAW application.

All entries are applied to the twx-analyzer instance for each analysis and for all projects.

It should also be noted that many entries may have a negative impact on performance, so it is advisable to check the list from time to time.

### Details - Full text search

#### Description

The fulltext search will eventually replace the existing search via predefined regular expressions (RegExp search). For the time being, however, both variants will remain.
There are two main differences between the two search options. For the RegExp search, in order to get results, the search parameter must be configured as a regular expression before the analysis. The fulltext search does not need any previous configuration. However, the RegExp search can show an exact path (tags in the XML) to the location of the found values from the elements (e.g. BPD or Service).

Each time a new snapshot is analyzed, the elements of the twx are indexed. It is important to know that the full text search currently only indexes and stores only those element types:
TwClass, BPD, Service, EPV, CoachView.
This restriction is necessary because it is not yet possible to estimate exactly how much storage space indexing will require. Of course, the search results are also limited to these object types.

The fulltext search needs at least a MongoDB in version 5


#### Configuration

The full text search is activated by default. However, it can be disabled at any time via the [configuration](settings.md#general-settings).
Additionally, there is the possibility to change the configuration at the first startup.
A description and list of the startup parameters can be found in the [installation manual](../installation/configuration.md#startup-configuration).

#### Indexing

Indexing is performed with each new analysis of a snapshot and only for the process app. With Release 2.3.3 toolkits are indexed as well. Keep in mind that we, on purposely do not index system toolkits. Those are configured in the system properties. 

With a new analysis the indexes of the previous analysis are deleted. This serves to save space and not to load the system with unnecessary data. The associated indexes are also deleted when a snapshot is deleted. In concrete terms, this means that when analyzing snapshot V1, the indexes for V1 are also created. When analyzing snapshot V2 (same project), the indices of V1 are deleted and newly created for V2. If V2 is now deleted, snapshot V1 is visible again in the snapshot overview, but has no indices for the fulltext search. Without uploading a new snapshot or re-analyzing the existing snapshot V1, no new indexes will be created and an error message may occur. In this case, the current snapshot V1 must be analyzed again.

#### Search

The full text search is located under "Develop -> Search". As everywhere you can use the key combination "ctrl + shift + f" to move the cursor into the text field of the full text search

![figure 1](../pictures/fulltextsearch.png "Figure 1: Full text search header")

Most punctuation characters in a search string are seen as separators. This can be seen well in an ID search if the ID was not surrounded by apostrophes. However, the exception to the punctuation is the hyphen. It is used (unless enclosed in \") to negate a word.

* Stop Words:

  If the search string contains so-called stop words (the, and, ...), these are ignored by the search.


* Word stem:

  When searching without case sensitivity, the complete root of a word is matched. So if a serivce contains the word blueberry, a search for the term "blue" will not be successful. However, blueberry or blueberries will match. 


* Negations:

  - The negated word will cause documents containing this word, to be excluded from the results list.
  - If there is a hyphen between two words without a space before the - (e.g. co-worker) this does not lead to the negation of the word worker.    


* Phrase:

  With this checkbox you can control whether the entered text is used as a unit or coherent text (if selected), or whether the specified words may occur in any order and in any places in a text.
  You can also crate a phrase by wrapping the text with \", but keep in mind that using a phrase and normal text in the search string, the result will only contain the results of which the phrase has matches. With 
```"\"IBM BAW\" service"``` only  ```"\"IBM BAW\""``` is used to create search results.


* Case sensitive:

  If this checkbox is selected, the search will be performed to the letter. The search will then contain only results where the words follow the upper or lower case of the search text. Case sensitive searches may be more performance demanding then non case sensitive searches. 


* Current Project:
  
  To search only in the values of the currently selected snapshot, this checkbox must be selected. Otherwise, the search will be performed over all available snapshots. It should be noted that currently it is not yet shown from which snapshot the respective encounter comes.


* Element list:
  
  This list contains all elements that are currently indexed. Only selected types are shown in the result list. If no checkbox is selected, all element types are included.


* Tk or App Filter:

  This list contains the toolkits and process app which are included in the search result. So you can filter out either results from the process app or any toolkit.


* ID search:
  
  With the full text search it is now easier to search for IDs. However, in order to get exact results, quotation marks should be placed around the ID to be searched.


!!! important "Partial Search"
    MongoDB does not yet support partial search, therefor if the name of a service is: ```ComplexHumanService``` and you type ```HumanService```, there will be no results. There is a feature request for this. Please feel free to upvote it: https://jira.mongodb.org/browse/SERVER-15090  

##### Handling search results

The results of the search are displayed below the search parameter bar.
When selecting a single search result, the JSON string of the object in which the value was found is displayed on the right side. The display can be completely collapsed using the "Toggle" button.
It is also possible to select multiple search results at the same time and thus display all Json strings simultaneously on the right side.
