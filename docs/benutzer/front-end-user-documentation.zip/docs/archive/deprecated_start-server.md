# DEPRECATED

## Run twx-Twxanalyzer

If the twx-Analyzer is not configured as a service you can run the server with these commands:
<!-- TODO mehr details -->

Linux:

    1. Start or check if Mongodb is started
    2. Open terminal window
    3. Navigate to the analyzer folder
    4. Start the twx-Analyzer
    `java -jar <analyzer-server-2.x.x>.jar`

Windows:

    1. Start or check if Mongodb is started
    2. Open command prompt
    3. Navigate to the analyzer folder
    4. Start the twx-Analyzer
    `java -jar <analyzer-server-2.x.x>.jar`


If the twx-Analyzer has started successfully, you will find a line similar to this in the log file:
    
!!! success
    INFO  .TwxAnalyzerBackendApplication logStarted : Started TwxAnalyzerBackendApplication in 11.743 seconds (JVM running for 12.908)

!!! tip
    In case you need to debug the servers' startup sequence, you can add a debug parameter to the start command: 
    
    java -Ddebug -jar analyzer-server-2.x.x.jar

## Run demo

During the initial startup the embedded MongoDB is downloaded, if this does fail please check the [section: demo installation](installing#demo-installation).
The demo requires a 64-bit Java 8 or higher. Therefore, we provided start scripts for Windows and Linux to check the prerequisites.

Windows:

    * start.cmd

Mac/Linux

    * start.sh