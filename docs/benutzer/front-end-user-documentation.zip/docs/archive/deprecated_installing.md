# DEPRECATED

### Installation

The manual installation steps are as follows:

<!-- TODO noch viel mehr Details einarbeiten -->

- Install the MongoDB.
- Install a Java version.
- Unzip the twx-Analyzer-2.x.x.zip file into the working folder.
- Continue to [run the twx-Analyzer](start-server.md)

#### Install MongoDB

We assume that you are installing the MongoDB on the same machine as where the analyzer is running. Therefor the Database is reachable with: localhost and the default port: 27017.
In other cases please contact our support.

The twx-Analyzer creates a database called twxAnalyzernew automatically if not existend.

<!-- If the database is on another server, we recomment to use the uri-configuration:  -Dspring.data.mongodb.uri=mongodb://localhost:27017 
https://stackoverflow.com/questions/50423896/how-to-configure-ssl-mongodb-connection-in-yml-file-spring-boot
https://docs.mongodb.com/manual/reference/connection-string/
https://docs.mongodb.com/manual/tutorial/configure-ssl/
https://zappysys.com/blog/configure-mongodb-ssl-connection-certificate/
-->

#### Installation with password secured MongoDB

In case you have a password secured MongoDB Installation you need to configure a password. Please make sure the authentication is setup in the twxAnalyzernew database. Otherwise please contact our support.
In addition, if the the database is passwort protected there are two prefered options on how to start the twxAnalzyer.

Option 1: Start the analyzer with a password parameter:

    java -Dspring.data.mongodb.password=password -Dspring.data.mongodb.username=username -jar analyzer-server.jar

Option 2: Create an environment variable to store the password:

    export SPRING_DATA_MONGODB_USERNAME=username
    export SPRING_DATA_MONGODB_PASSWORD=password

More information on option 2 at the [spring boot documentation](https://docs.spring.io/spring-boot/docs/1.5.5.RELEASE/reference/html/boot-features-external-config.html)

### Demo installation

In case you are running one of our demos, the required files for the embedded mongodb are automatically downloaded during the first startup. If you have no internet access or if your user has no rights to create the '.embedmongo' folder in your home directory, you can manually copy the files to their target location. Otherwise you can simply move ahead and [run the twx-Analyzer demo](start-server.md).

These are the paths where the embedded mongodb files are expected:

    Windows:   %HOMEPATH%/.embedmongo/win32/mongodb-win32-x86_64-3.5.5.zip
    Linux:     $HOME/.embedmongo/linux/mongodb-linux-x86_64-3.5.5.tgz
    Mac:       $HOME/.embedmongo/osx/mongodb-osx-x86_64-3.5.5.tgz

Downloading the MongoDB file manually:

!!! note "Download links:"
    https://fastdl.mongodb.org/osx/mongodb-osx-x86_64-3.5.5.tgz

    https://fastdl.mongodb.org/win32/mongodb-win32-x86_64-3.5.5.zip

    https://fastdl.mongodb.org/linux/mongodb-linux-x86_64-3.5.5.tgz
