﻿# Multi-Tenancy

The TWX-Analyzer supports a multi-tenancy mode that restricts user access to specific Process Applications based on their LDAP group membership.

## Configuration

To enable multi-tenancy, you must start the application with the following system property. **A restart is required** for this change to take effect.

- `system.tenant.mode-active=true` (Default is false)

## How it Works

1. **Access Control:** When enabled, users can only see and analyze Process Applications that are explicitly assigned to their tenant. Access to unauthorized apps results in a `403 Forbidden` error.
2. **Tenant Resolution:** The system determines a user's tenant by checking their LDAP groups.
   - **Priority Rule:** If a user belongs to multiple groups mapped to different tenants, the system selects the tenant based on the **alphabetical order** of the user's groups.
   - **Deny by Default:** If a user does not belong to any group mapped to a tenant, they will have no access to any Process Applications.

## Management API

There is no graphical user interface for managing tenants. All configuration is done via the REST API.

**Security:** Only the user specified in the `system.tenant.api.username` property (Default: `user01`) is authorized to use these endpoints. A valid Bearer Token is required.

### Endpoints

- **List Tenants:** `GET /api/tenants`
- **Create Tenant:** `POST /api/tenants`
  ```json
  {
    "tenantId": "my-tenant",
    "allowedProcessApps": ["ACRONYM1", "ACRONYM2"],
    "groups": ["ldap-group-1"]
  }
  ```
