# Overview installation guide

The standalone installation on a bare linux or windows system is not longer supported. We recommend to use the Helm-Chart for the installation on OpenShift. In case you need to install on kubernetes, please feel free to contact us.

## Basic information

The twx-Analyzer is based on Spring boot and is delivered as a docker image, which is based on a linux distribution, and installed via a Helm-Chart.
Other components or images of the Helm-Chart are a MongoDB and a nginx server.

It is possible to request a demo version for which there might be some exceptions in the configuration and provided information.

### [Configuration](configuration.md)

This section contains description about additional startup parameters, like configuring different ports or adding certificates, ...

## Requirements

    1. MongoDB Versions 
    1.1 Without using full text search
        - V4.0 to V8.x
        - V3.x
    1.2 When using full text search
        - V5.x to V8.x

    2. Java Runtime version 17/21
        
    3. Firefox version 129 or higher
    4. Internet Explorer is NOT supported
    5. Microsoft Edge is NOT fully supported

## Installation

We recommend a Helm-Chart installation on OpenShift. In case you need to install on kubernetes, please feel free to contact us.

More information about the installation can be found in the [Helm installation](installation.md) section.