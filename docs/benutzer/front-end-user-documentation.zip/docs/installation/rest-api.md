# REST API Usage and Configuration

## Swagger-UI

If you have enabled the REST API in your twx-Analyzer instance (default is true), you can access the Swagger-UI at the following URL:

URL: `http://<twx-analyzer-host>/twx/swagger-ui/index.html`.

### Configure Your twx-Analyzer Instance

By default, the URL of your twx-Analyzer instance is automatically set as the base URL in the Swagger-UI.
If you want to change this base URL to a different value, go to the Helm chart file `analyzer\deployments.yaml`
and change the value of the environment variable `CUSTOM_API_SERVER_URL` to the desired URL.

### Login

To use the REST API, you need to authenticate with a Bearer token. You can obtain this token by logging in with your credentials.

In the Swagger-UI, look for the section `-Authentication-` and choose the POST endpoint `/api/auth/login`.
Click the `Try it out` button and enter your credentials in the JSON body. The Swagger-UI will send:

```json
{
  "username": "<your-username>",
  "password": "<your-password>"
}
```

Then click the `Execute` button. 
If the login is successful, the Swagger-UI will return a 200 OK response with a Bearer token in the response body.
The response will look like this:

```json
{
    "user": {
      "username": "user01"
    },
    "accessToken": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJfc2VyMDEiLCJpc3MiOiJ0d3gtYW5hbHl6ZXIiLCJpYXQiOjE3NDU4NzUxOTAsIkF1dGhvcml0aWVzIjpbIlJPTEVfUkVBREVSUyJdLCJleHAiOjE3NDY0Nzk5OTB9.1vs6uEq4Oy6QR37A9PJqaTIErV0ptI12LtGO57azPPyNXT74-dsUEGjD1voyCwjtA_lT6VV-s9oGbd7Go1BVgQ",
    "tokenType": "Bearer"
}
```

The `accessToken` field contains the Bearer token you need to use in your API requests.
The `tokenType` field indicates that it is a Bearer token. 
Copy the bearer token from the response body and paste it into the `Authorize` header of your API requests.

Now you can use the other API endpoints in the Swagger-UI.

## Alternative Calls
Of course, you can also use curl or an HTTP client (such as in IntelliJ) to call the REST API. Here is a short HTTP file that you can use to test the REST API with IntelliJ: example for CI integration.