# Integration in build automation system (CI/CD)

## Overview

The twx-Analyzer provides REST-based endpoints to automate its core functionality—analyzing IBM BAW or ISF project snapshots for code-quality and rule violations. By calling these endpoints in your pipeline scripts or build jobs, you can detect coding issues earlier in the lifecycle and enforce development guidelines continuously.

Key points:

* **Automatic Snapshot Export & Analysis** \
Pipelines can programmatically trigger twx-Analyzer to download snapshots from IBM BAW (or upload snapshots previously exported) and perform a full rule-based code analysis.


* **Fail-Fast / Gate Mechanism** \
Because the analyzer returns a structured list of findings (errors, warnings, bad styles), you can parse these results in your CI pipeline and decide whether to proceed (e.g., if there are zero errors) or fail the build.


* **REST Endpoints & OpenAPI Specifications** \
Each twx-Analyzer version publishes an OpenAPI YAML file for the CI endpoints (e.g., [openapi_ci_v3.0.1.yaml](./openapi_ci_v3.0.1.yaml)). This allows easy tooling integration in Jenkins, Azure DevOps, or any platform that can do HTTP requests.

## Prerequisites / setup

Use your standard twx-Analyzer installation/setup for the CI/CD integration. Or if you have sufficient licensing create a dedicated instance for CI/CD. We reccommend to use the same plugins and configration you would use for a regular snapshot analysis. Like developers would use to verify a new snapshot after a new implementation of fix is ready.

## Typical CI/CD Workflow

Below is a common pattern for integrating twx-Analyzer into a build pipeline:

   1. Final Snapshot generation

      * Your usual snapshot creation steps (e.g. create or export a snapshot .twx file or have the analyzer automatically download the snapshot from the Process Center). 
      
      * Hint: There is no capability to automatically create a new snapshot via the REST API through the twx-Analyzer.

   2. Trigger twx-Analyzer

      * Remote Download: Let twx-Analyzer automatically pull the snapshot from BAW using its built-in remote download capability.

      * Manual Upload: Or have your pipeline script upload the snapshot file via the REST API if you have it exported locally. 

   3. Analysis Execution

      * Define the level of result granularity for the results. You can choose between single result values or more fine grained results. Checkout the OpenApi specification for more details.
      * The pipeline instructs twx-Analyzer to analyze the newly retrieved or uploaded snapshot.
      * The analyzer runs all configured plugins and returns a list of findings (errors, warnings, style issues, etc.). 

   4. Parse Results 

      * Your CI job parses the JSON or text output to check for any critical errors. 
      * If the analyzer reports zero or an acceptable threshold of errors/warnings, the pipeline can continue to the next stage. Otherwise, it fails immediately for quick feedback. 

   5. Reporting 
   
       * The pipeline can gather the findings from twx-Analyzer and publish them in your standard reporting format, e.g., pipeline logs, HTML artifacts, or issue tracking system. 
       * Over time, you can compare the results to track improvements or new regressions.

## Key Features for CI/CD

1. Dedicated REST API Calls

    * Endpoints are provided for uploading/downloading snapshots, triggering analysis, and retrieving the findings.
    
    * The twx-Analyzer also supports analyzing by process acronym (e.g., for BAW projects) so you do not have to look up UUIDs IDs each time.

2. OpenAPI

    * Use the OpenAPI YAML file to generate client libraries or API documentation for your CI/CD platform.
    * You can also access the swaggerUI (if enabled) to test the API calls directly in the browser. URL: `http://<twx-analyzer-host>/twx/swagger-ui/index.html`.
    * You may want to check out this example .http-file for a quick start: [example for ci integration](./twx_cicd.http).

3. Lightweight & Container-Friendly

    * twx-Analyzer can be deployed via Helm charts into container environments like OpenShift.
    * The same container can be used across different pipeline stages or ephemeral test environments.

4. Automation-Friendliness

    * Once the analyzer is configured (e.g., connected to the BAW server, plugin folder set, etc.), no manual intervention is required.
    * The pipeline can directly call the analyzer for each new code change or newly exported snapshot.

!!! tip "Performance"
    Be aware that many CI/CD API calls can have effects on the performance of the twx-Analyzer. Make sure to monitor the performance and adjust the configuration if" necessary.

!!! info "Queueing"
    We are planing to limit concurrent requests with queueing in future releases to avoid performance issues.


## Technical Setup Steps

1. Install & Configure twx-Analyzer

    * Make sure it has network access to the BAW Process Center if you plan on using the automatic (remote) snapshot download.
    * Configure TLS certificates and credentials as needed (e.g., BAW admin user).

2. Enable the CI Endpoints

    * Check the property system.security.cicd (true by default) or ensure your environment is set up so that the REST endpoints can be used. We strongly recommend to leave the default and use credentials via your pipeline.
    
3. Obtain OpenAPI Specification

    * Download the earlier mentioned `openapi_ci_v3.x.x.yaml` to see the exact endpoints, request bodies, and response formats.

4. Inspect the Findings

    * twx-Analyzer returns a structured JSON. Each finding includes severity, location, and message.
    * Parse that JSON and count error or specific [findingTypes](../components/analyze.md#findingtypes) then fail your pipeline if needed.


Sample for non-detailed findings output:

```json
{
    "errors": 1,
    "warnings": 2,
    "badStyles": 0
}
```

Sample for a detailed findings output: 

```json
{
    "errorCount": 23,
    "warningCount": 0,
    "badStyleCount": 0,
    "errorCountPerFindingTypeMap": {
      "Unbound Error Variable": 19,
      "UCA Condition Without 'return true'": 4
    },
    "warningCountPerFindingTypeMap": {},
    "badStyleCountPerFindingTypeMap": {}
}
```

5. Best Practices & Tips

    * Fail Early: Configure your pipeline to fail on major code-quality regressions (e.g., any new “Error” severity finding). This prevents problems from snowballing late in the release cycle.
    * Use Snapshots Wisely: Typically, you only want to analyze the “Latest” or a “Pre-deployment” snapshot. Over-analyzing partial or ephemeral snapshots can lead to unnecessary pipeline overhead. And heat in terms of performance on the twx-Analyzer instance. 
    * Keep twx-Analyzer Updated: Ensure you upgrade to a release that aligns with the BAW version in your environment. 
    * Combine with Other Checks: In your pipeline or pre deployment steps, you might also run unit tests and UI tests.
    * Use the swaggerUI to test the API calls directly in the browser or an appealing well readable visualisation of the API. URL: `http://<twx-analyzer-host>/twx/swagger-ui/index.html`.
    * Use the [.http file](twx_cicd.http) to test the API calls in your IDE or Postman. 
```http request

```

