There are lots of configuration possibilities for the twx-Analyzer. The following section will give you an overview of the most important configurations.

### Startup Configuration

#### Helm-Chart controlled

When starting the application, some parameters can already be changed that influence the application. Roughly the configuration can be divided into 2 parts 1. technical and 2. application related parameters.

##### Users

The BAW/BPM administrative user or password is provided in the HELM Chart via secrets or in case of a jar-deployment as an environment variable

```YAML
secrets:
    baw_technical_user: admin
    baw_technical_user_pw: admin
```

Resulting in environment-variables:
BAW_TECHNICAL_USER and BAW_TECHNICAL_USER_PW


#### Other technical parameters

| Parameter | values | note | 
| :------------ | :-------| :-------- |
| logging.file.max-size | xxxMB | Control of the log file size |
| server.port | 8082 | Default server port e.g 8082 | 
| management.port | 9091 | Default management port e.g 9091 |
| debug | none | Debug Mode enabled whne parameter is set without value |
| server.ssl.enabled | true/false | Disable SSL | 
| server.ssl.key-store-type | PKCS12 | The format used for the keystore. It could be set to JKS in case it is a JKS file |
| server.ssl.key-store | keystore/twxAnalyzer_keystore.p12 | The path to the keystore containing the certificate |
| server.ssl.key-store-password | changeit | The password used to generate the certificate |
| server.ssl.key-alias | twxAnalyzer | The alias mapped to the certificate |


System

System configurations are used as database default values at a first startup. Afterward they have to be changed via the webfrontend.

| Parameter                                     | Default Value                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | Note                                                                                                                                                                                                          |
|:----------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| javax.xml.transform.TransformerFactory        | net.sf.saxon.TransformerFactoryImpl                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Configures the TransformerFactory to use Saxon Parser instead of the default XML Parser.                                                                                                                      |
| system.analysis.keep-files                    | true                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Keep uploaded files after analysis.                                                                                                                                                                           |
| system.analysis.isf-features                  | false                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | ISF feature switch.                                                                                                                                                                                           |
| system.analysis.exclude-toolkits              | SYSRC,SYSRPC,SYSCM,SYSBPMUI,TWSYS,SYSC                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Default excluded toolkits or process apps.                                                                                                                                                                    |
| system.analysis.umlaut-replacement            | true                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Enable umlaut replacement.                                                                                                                                                                                    |
| system.analysis.remote-download               | false                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Enable remote download capabilities.                                                                                                                                                                          |
| system.analysis.plugins-folder                | plugins                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Default location of the plugin folder. To set a different folder at startup, use `-Dsystem.overwrite.plugins.folder=xyz` or set the environment variable `SYSTEM_OVERWRITE_PLUGINS_FOLDER=xyz`.               |
| system.analysis.fulltextsearch                | true                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Enables full text search.                                                                                                                                                                                     |
| system.servers.map.bpm.hostname               | ibmbaw                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | BPM server hostname.                                                                                                                                                                                          |
| system.servers.map.bpm.port                   | 9443                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | BPM server port.                                                                                                                                                                                              |
| system.servers.map.bpm.protocol               | https                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | BPM server protocol.                                                                                                                                                                                          |
| system.servers.map.bpm.use-webclient          | true                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Use web client for download.                                                                                                                                                                                  |
| system.servers.map.bpm.new-download-api       | true                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Use new download API.                                                                                                                                                                                         |
| system.servers.map.isf.username               | admin                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | ISF username. (deprecated)                                                                                                                                                                                    |
| system.servers.map.isf.password               | admin                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | ISF password. (deprecated)                                                                                                                                                                                                |
| system.base-plugin.search-query-conceptnames  | namespace:\w+ \| other:\w+                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | Search query concept names.                                                                                                                                                                                   |
| system.base-plugin.loggername-variable        | localLoggerName                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Logger name variable.                                                                                                                                                                                         |
| system.base-plugin.loggername-variable-regexp | tw.local.localLoggerName\s*=\s*"(.*)";                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Logger name variable regexp.                                                                                                                                                                                  |
| system.general.ignore-tag-group-name          | TwxAnalyzerIgnores                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | Group name to ignore tags.                                                                                                                                                                                    |
| system.general.diff-context-size              | 3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Difference context size.                                                                                                                                                                                      |
| system.general.snapshot-history               | 2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Snapshot history.                                                                                                                                                                                             |
| system.general.diff-removeable-tags           | lastModified, lastModifiedBy, modificationDate, versionId, guid, jsonData, parameterMappingId, parameterMappingParentId, bpdParameterId, tWComponentId, bpdEventId, faultParameterId, switchConditionId, endStateId, outputPort/@id, inputPort/@id, defaultInstanceUI/@id, ownerTeamInstanceUI/@id, expression/@id, condition/@id, inputPort/@id, outputPort/@id, assignment/@id, inputSet/@id, outputSet/@id, laneFilter/@id, htmlHeaderTag/@id, formTask/@id, teamFilter/@id, EventAction/@id, EventActionImplementation/@id, inputActivityParameterMapping/@id, extension/@id, coachEventBinding/@id, artifactReference/@id, nameValuePair/@id, layoutItem/id, configData/id, contentBoxContrib/id | Tags that can be removed during diff.                                                                                                                                                                         |
| system.tenant.api.username                    | user01                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | User allowed to manipulate tenant configuration.                                                                                                                                                              |
| system.tenant.mode-active                     | false                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Tenant mode active.                                                                                                                                                                                           |
| system.support.email.active                   | false                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Not yet active - Email support active.                                                                                                                                                                        |
| system.support.email.address                  | fobar@127.0.0.1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Not yet active - Support email address.                                                                                                                                                                       |
| system.support.email.host                     | localhost                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | Not yet active - Support email host.                                                                                                                                                                          |
| system.support.email.port                     | 2075                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Not yet active - Support email port.                                                                                                                                                                          |
| system.support.email.username                 | USERNAME                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | Not yet active - Support email username.                                                                                                                                                                      |
| system.support.email.password                 | PASSWORD                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | Not yet active - Support email password.                                                                                                                                                                      |
| system.security.cicd                          | true                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | If true, security for the CICD endpoints is enabled. If false, they can be used without proper login.                                                                                                         |
| system.security.actuator                      | true                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | If true, security for all actuator endpoints is enabled, except health and info. If false, they can be used without proper login.                                                                             |
| ldap.securityPropertiesPfad                   | ''                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | Default is empty string. It is used to search for the location the security.properties. If not set the file is expected to be at the same folder. In the docker environment the file is placed under root '/' |



### Changing the certificate

It is possible to use your own certificates with the twx-Analyzer. For that you need to configure these parameters:

```
// The format used for the keystore.
server.ssl.key-store-type: PKCS12
// The path to keystore
server.ssl.key-store: keystore/twxAnalyzer_keystore.p12
// The default password for the certificate is
server.ssl.key-store-password: changeit
// The alias
server.ssl.key-alias: twxAnalyzer
```

#### Server-Certificate for online connection

<!-- Import Certificate: https://www.ibm.com/support/knowledgecenter/SSUS84_7.5.2/com.ibm.ram.installguide.doc/topics/t_install_eclipse_https.html
https://azure.microsoft.com/en-us/documentation/articles/java-add-certificate-ca-store/ -->
If you need a connection to BPM for automatic downloads, you must include the BPM ProcessCenter certificate into the JVM keystore. The same might apply for the connection to the ldap server.

**Exporting the IBM BPM Certificate:**

1. Open the `processAdmin`.
2. Use your browser to view and export the certificate locally.

**Importing the Certificate to Java Keystore:**

1. Open a command prompt and navigate to the Java `bin` directory:
    ```bash
    cd "C:\Program Files\Java\jre1.8.0_51\bin"
    ```

2. Import the exported certificate into the JVM keystore:
    ```bash
    keytool.exe -import -keystore ..\lib\security\cacerts -alias ibmbpm856 -file "<Path>\exportedBPM.crt"
    ```
    - **Default Password:** `changeit`

3. **Listing All Available Certificates:**
    ```bash
    keytool.exe -list -keystore ..\lib\security\cacerts
    ```

<!-- Export certificate: https://liangjunjiang.medium.com/ldaps-certificate-in-spring-boot-application-and-its-docker-image-cf7785acef8f -->
<!-- https://stackoverflow.com/questions/27724544/specifying-trust-store-information-in-spring-boot-application-properties -->

##### SSL configuration

Alternatively, you can use OpenSSL to retrieve and add the certificate to the Java keystore:

1. Retrieve the certificate using OpenSSL:
    ```bash
    openssl s_client -showcerts -connect ldapserver:636
    ```
    - The output will contain multiple entries delimited by:

        ```
        -----BEGIN CERTIFICATE-----
        aklfhskfadljasdl1340234234ASDSDFSDFSDFSDFSD
        -----END CERTIFICATE-----
        ```

2. Save the Certificate:
   - Copy the last certificate entry into a file (ldapca.crt)

3. Import the Certificate into Java Keystore:
   ```bash
   $ cd %JAVA_HOME%\lib\security
   $ keytool -import -alias ldapca_self_sign -keystore cacerts -storepass changeit -file ldapca.crt
    ```

#### Truststore

If you are planing to connect to the IBM BAW ProcessCenter there are 3 possibilities to solve the certificate issues.
1. Import your domain certificates into the keystore and override the default keystore.
2. Import the certificate into the java key store, as described in the previous section
3. Import the server certificate into a trust store and add the following parameters to your start command:
`-Djavax.net.ssl.trustStore=..\path_to_cert\filename.crt -Djavax.net.ssl.trustStorePassword=xxxxxxx`

If the target servers such as Active Directory or Process Center are not in the same network as the twx analyzer and 
the certificates differ as a result, the third variant should be selected, which is no longer available with the Helm-Chart Deployment. In this case please contact us.

### More configuration parameters

Spring boot, on which the application is build on, offers some more configuration alternatives. You can read about those in the [spring documentation](https://docs.spring.io/spring-boot/docs/current/reference/html/spring-boot-features.html#boot-features-external-config). So one alternative is to set environment variables. And for that you can transform the configuration name into a environment variable like:

[//]: # (    -Dserver.port to SERVER_PORT)
[//]: # (And then use the variable in your .bashrc)
[//]: # (    export SERVER_PORT=8443)
[//]: # (A dash will be replaced with no value. Lets have a look at some examples:)
[//]: # (    server.ssl.key-store-type     --> SERVER_SSL_KEYSTORETYPE)
[//]: # (    server.ssl.key-store-password --> SERVER_SSL_KEYSTOREPASSWORD)
[//]: # (<!-- https://github.com/spring-projects/spring-boot/wiki/Relaxed-Binding-2.0 -->)

### Shutdown Endpoint

By default, the shutdown endpoint is enabled reachable via

    curl -X POST http://localhost:9090/actuator/shutdown

To turn off this capability, start the server with additional configuration:

    -Dmanagement.endpoint.shutdown.enabled=false


<!--
### Login Behavior
There are two options in the twx-Analyzer use LDAP as the user provider or use the possibility to save register new users, which are then saved in the mongoDB.

#### Controll user repository (MongoDB) 
If you decide to go with the mongoDB ask our support for settings.
-->

### Login with LDAP repository


#### Overwrite security.properties

Normally the security.properties file is used to configure the Active Directory
or LDAP configuration. Alternatively, the parameters can be passed as arguments when starting the application.

This would look like this:

| Parameter                    | Default Value                                                             | Note                                               |
|:-----------------------------|:--------------------------------------------------------------------------|:---------------------------------------------------|
| ldap.url                     | awstswn086.twx-solutions.net                                              | URL of the LDAP server                             |
| ldap.port                    | 636                                                                       | Port for LDAP connection                           |
| ldap.baseDn                  | DC=TWX-SOLUTIONS,DC=NET                                                   | Base Distinguished Name for LDAP                   |
| ldap.managerDn               | CN=TWX2BPM,OU=UsersTechnical,OU=UserAccessService,DC=TWX-SOLUTIONS,DC=NET | Distinguished Name of the LDAP manager             |
| ldap.managerPassword         | xxx                                                                       | Password for the LDAP manager account              |
| ldap.userSearchBase          | OU=UserAccessService                                                      | Base OU for user searches                          |
| ldap.userSearchFilter        | "(cn={0})"                                                                | Filter used to search for users                    |
| ldap.sslEnabled              | true                                                                      | Enables SSL for LDAP connections                   |
| ldap.groupSearchBase         |                                                                           | Base OU for group searches (if applicable)         |
| ldap.groupSearchFilter       |                                                                           | Filter used to search for groups (if applicable)   |
| ldap.searchControllerEnabled | true                                                                      | Enables the search controller functionality        |



### LogLevel Configuration

To change the log level, a rest api (http) endpoint is provided.

Request LogLevel via curl:

    curl -i -k http://localhost:9090/actuator/loggers/de.ssee.analyzer.plugin

Change LogLevel via curl:

    curl -i -X POST -H 'Content-Type: application/json' -d '{"configuredLevel": "TRACE"}'
    
    http://localhost:9090/actuator/loggers/de.ssee.analyzer.plugin

### twx-Analyzer configuration

Please see the ["Settings"-section](../components/settings.md) of the twx-Analyzer the following configurations are available.
