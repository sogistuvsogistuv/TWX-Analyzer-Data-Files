## Helm Installation

Before you can install the Helm charts, ensure that the necessary configurations are in place as outlined below.

### Configure Charts

#### 1. Configure `dockerConfigJson` in `values.yaml`
To authenticate with your registry:
```sh
# Log in to your registry (this creates or updates ~/.docker/config.json)
docker login twxsolutions.jfrog.io --username <your-username> --password <your-password>

# Encode the config file
cat ~/.docker/config.json | base64 -w 0
```
Add the base64-encoded value to the `dockerConfigJson` field in `values.yaml`.

---

#### 2. Replace the Default Logo
Replace the `logo.png` file located at `twx-analyzer/configs/nginx/assets/` with your organization's logo.

---

#### 3. Configure LDAP Settings
Edit the `security.properties` file in the `twx-analyzer/configs/ldap/` folder to specify the appropriate parameters for connecting to your LDAP server (e.g., Microsoft Active Directory).  
For detailed information, see the [LDAP configuration guide](configuration.md#ldap-configuration).

---

#### 4. Update Keystore with Required Certificates
Add the necessary certificates for your infrastructure (e.g., for connecting to the LDAP server) to the `twxAnalyzer_keystore.p12` file located in the `twx-analyzer/configs/keystore/` folder.

---

#### 5. Add Certificates for TLS Communication
In the `twx-analyzer/configs/certs/` folder, add the following files:
- `tls.crt`: The TLS certificate
- `tls.key`: The private key
- `ca.crt`: The CA certificate

These files are required for the Route resource to configure TLS settings for secure communication with custom certificates and re-encrypt TLS termination.

---

#### 6. Identify the Correct Storage Class
Determine the correct storage class name for your environment by running:
```sh
kubectl get storageclass
```
Update the storage class configuration in the Helm chart accordingly.

---

#### 7. Configure the Route Host
Set the `route.host` value in the Helm chart to match your environment's configuration.

---

#### 8. Set Up BAW Server Connection
To enable all features, configure the connection to the BAW server. Set the secrets for `baw_technical_user` and `baw_technical_user_pw` in the `secret.yaml` file located at `twx-analyzer/templates/analyzer/secret.yaml`.  
Both values must be base64-encoded. Example:
```sh
... --set analyzer.secrets.baw_technical_user=admin \
    --set analyzer.secrets.baw_technical_user_pw=admin
```

#### 9. Configure your default theme

Configure your default theme in the frontend-config.json configMap. You can choose between the following themes:
* default-material (default)
* yellow-material
* blue-material

!!! important "Latest Release 3.0.1" 
    Do not leave any comment or other non-valid json in the 'frontend-frontend-configjson' ConfigMap. This will lead to a crash of the frontend. With a message similar to this:
    ```text
    Unhandled Promise rejection: Expected ',' or '}' after property value in JSON at position 129 (line 7 column 38) ; Zone: <root> ; Task: Promise.then ; Value: SyntaxError: Expected ',' or '}' after property value in JSON at position 129 (line 7 column 38) SyntaxError: Expected ',' or '}' after property value in JSON at position 129 (line 7 column 38)
    ```

##### 9.1. Configure api url timeouts

You can configure the api url timeouts in milliseconds in the frontend-config.json configMap. The default values are:
```json
{
  ...
  "defaultTimeout": 30000,
  "endpointTimeouts": {
    "/api/upload": 120000,
    "/api/analyze": 120000,
    "/api/reanalyze": 120000,
    "/api/bpm/download": 60000,
    "/api/bpm/download/snapshot": 60000,
    "/api/bpm/processApp/all": 60000,
    "/api/bpm/processApp/snapshots": 60000,
    "/api/snapshot/diff": 120000,
    "/api/snapshot/analyze/all/tree": 60000
  }
}
```

### Timeouts

The default timeout settings for the nginx server are:
```nginx configuration
    proxy_connect_timeout       605;
    proxy_send_timeout          605;
    proxy_read_timeout          605;
    send_timeout                605;
    keepalive_timeout           605;
```

These are set in the default.conf. One may change these values according to their needs. Especially in project with huge exports this might be necessary to further increase.

### Installation

You can install the Helm charts by running:

`helm install <YOUR HELM RELEASE NAME> ./twx-analyzer --set route.host=<twx-analyzer DNS name> --set pvc.storageClass=<storage class name>`


### Uninstalling Charts

You can remove these charts by running:
`helm uninstall <YOUR HELM RELEASE NAME>`