# Header Files


Code name: 'headerSaveExecutionContext':

![[Material for MkDocs]](../../pictures/header_files/headerSaveExecutionContext.png)

Code name: 'headerCatchAll':

![[Material for MkDocs]](../../pictures/header_files/headerCatchAll.png)

Code name: 'headerServiceNotAttached':

![[Material for MkDocs]](../../pictures/header_files/headerServiceNotAttached.png)

Code name: 'headerExceptionCodeMismatch':

![[Material for MkDocs]](../../pictures/header_files/headerExceptionCodeMismatch.png)  

Code name: 'headerStraightThrough':

![[Material for MkDocs]](../../pictures/header_files/headerStraightThrough.png)

Code name: 'headerExceptionTypeMismatch':

![[Material for MkDocs]](../../pictures/header_files/headerExceptionTypeMismatch.png)

Code name: 'headerNextServiceItem':

![[Material for MkDocs]](../../pictures/header_files/headerNextServiceItem.png)

Code name: 'headerUnattachedExit':

![[Material for MkDocs]](../../pictures/header_files/headerUnattachedExit.png)

Code name: 'headerUnboundErrorVariable':

![[Material for MkDocs]](../../pictures/header_files/headerUnboundErrorVariable.png)

Code name: 'headerNoEntryLogging':

![[Material for MkDocs]](../../pictures/header_files/headerNoEntryLogging.png)

Code name: 'headerUncaughtException':

![[Material for MkDocs]](../../pictures/header_files/headerUncaughtException.png)

Code name: 'headerNoExitLogging':

![[Material for MkDocs]](../../pictures/header_files/headerNoExitLogging.png)

Code name: 'headerProxyCatchAll':

![[Material for MkDocs]](../../pictures/header_files/headerProxyCatchAll.png)

Code name: 'headerGenericA5':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA5.png)

Code name: 'headerGenericB1':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB1.png)

Code name: 'headerGenericB9':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB9.png)

Code name: 'headerGenericA10':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA10.png)

Code name: 'headerGenericA6':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA6.png)

Code name: 'headerGenericB2':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB2.png)

Code name: 'headerGenericA11':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA11.png)

Code name: 'headerGenericA7':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA7.png)

Code name: 'headerGenericB3':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB3.png)

Code name: 'headerGenericA12':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA12.png)

Code name: 'headerGenericA8':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA8.png)

Code name: 'headerGenericB4':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB4.png)

Code name: 'headerGenericA1':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA1.png)

Code name: 'headerGenericA9':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA9.png)

Code name: 'headerGenericB5':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB5.png)

Code name: 'headerGenericA2':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA2.png)

Code name: 'headerGenericB10':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB10.png)  

Code name: 'headerGenericB6':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB6.png)

Code name: 'headerGenericA3':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA3.png)

Code name: 'headerGenericB11':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB11.png)  

Code name: 'headerGenericB7':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB7.png)

Code name: 'headerGenericA4':

![[Material for MkDocs]](../../pictures/header_files/headerGenericA4.png)

Code name: 'headerGenericB12':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB12.png)

Code name: 'headerGenericB8':

![[Material for MkDocs]](../../pictures/header_files/headerGenericB8.png)
