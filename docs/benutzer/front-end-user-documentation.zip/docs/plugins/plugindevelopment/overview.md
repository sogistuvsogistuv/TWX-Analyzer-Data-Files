# Overview of Plugin implementation

To create a new plugin register an account with download.twx-analyzer.de. There you can download a sample project to create a new plugin project.

The new project will contain a lib-folder in which the latest "Development Kit" (analyzer-SDK.jar) resides. This lib is only needed during development and should not be packaged with the new plugin jar.

The next step is to decide which ElementTypes your plugin can handle and anotate the Class with the correct elements:

```Java
@PluginTarget(type = {ObjectType.PROCESS, ObjectType.BPD})
```

Each plugin can create several so called [findingTypes](../../components/analyze.md#Findingtypes). At first these findingsTypes need to be defined. Use the FindingTypeBuilder in class FindingType. In the end, add the new FindingType to the list of all findingTypes via the method 'getLstFindingTypen()'.


This is an example:
```Java
// SETUP YOUR NEW FINDING TYPE
FindingType findingTyp =
    new FindingType.FindingTypeBuilder()
        .setLongDescription(
            "Description of the FindingType so that users known what issue is displayed in the below list of findings.")
        .setTitle("Readable Name Sample") // This is the readable name of the finding.
        .setFindingTypeId(SAMPLE_PLUGIN_FINDINGTYPEID)
        .setShortName(SAMPLE_PLUGIN_NAME)
        .setSeverity(Severity.ERROR)
        .setShortDescription(
            "This is the description that will be displayed if the power users mode is enabled.")
        .setMessageTemplate(
            "The item {ITEM} has an save execution context.") //
        .setHeaderImageUrl(ConstantsHeaderImageUrl.ITEMHASSAVEEXECUTIONCONTEXT)
        .setSolution(
            "Set a default value for the environment variable or to be more precise set a value for each target stage.")
        .buildFindingType();

getLstFindingTypen().add(findingTyp);
```

The analyzer runs each plugin on each element type, if the ObjectTypes (Check the enum class for the availabe different types) match. So the analyzer runs the method:
```java
List<Finding> performAnalysisGetFindings(String snapshotId);
```
on each turn.

Before the performAnalysisGetFindings method is called the initialize method is executed. Within this method the variable singleFileRepresentationElement is set. This is important since the variable is of type BaseTypeFileRepresentationInterface and may contain all sorts of classes which inherit from this base class. Each element type like bpd or process or uca inherit from this base class. So, in order to find out which element the current run is handling, check with java instanceof.

```Java
if (singleFileRepresentationElement
        instanceof ProcessTypeFileRepresentationInterface) { // Is ProcessType (Service)
```

Now you can start creating new plugins.

If the plugin is finished, upload it to the plugin folder and restart the server. The correct folder can be found in the [configuration](../../components/settings.md#general-settings) section.

## Plugin configuration

I case the plugin needs changeable settings, you can do this as well. In the sample plugin project, there is a sample.

```Java
public List<ConfigItem> getPluginDefaultConfigItems() {

    final String GROUP_NAME = "myOwnPluginGroup";
    if (configItems == null) configItems = new ArrayList<>();

    configItems.add(ConfigItem.builder()
            .name("uniqueName")
            .type(ConfigFrontendElementType.TEXT_TYPE)
            .valueText(config.getBasePlugin().getLoggernameVariableRegexp())
            .pluginClassName(this.getClass().getSimpleName())
            .findingTypeId(findingTypeId)
            .label("Regular expression for identifying the loggername content")
            .placeholder("Default: " + config.getBasePlugin().getLoggernameVariableRegexp())
            .groupBy(GROUP_NAME)
            .build());

    log.debug("Leaving with config: {}", configItems);
    return configItems;
}
```

Check the javadoc for further information