# Overview standard plugins

Plugins are created to find errors, warnings, bad style implementations. 

Basically there are two types of plugins. Those which are tightly bundled with the product and those which were customized to your project needs. Below topics cover all currently available plugins, that are included in the standard installation. A list of plugins, which are available in your current twx-Analyzer setup, is accessible at the settings tab in subsection "plugins" of the twx-Analyzer.

One of the main aspects of the twx-Analyzer is that projects or institutions can develop their own plugins. Please contant us if you plan to do so. <!--[develop their own plugins](../plugindevelopment/overview.md).-->

## [Error Plugins](details/error-plugins.md)

Most error findings would result in a runtime error.

## [Warning Plugins](details/warning-plugins.md)

Warnings may be performance related or could be cases, that do not follow your [good practices](../bestpractices/all.md).

## [Bad Style Plugins](details/badstyle-plugins.md)

This simply contains findings, which do not follow certain style guides or common agreements.

## Other Plugins

These types of plugins are informational list, which do not necessarily point towards a problem. They could be used to extract certain recurring information. So far none of these plugins are available with the standard delivery.


## More information
### Ignore findings
In case of 'false positives' or for some reason the results of a specific finding type should be ignored, the analyzer uses tagging to accomplish this task. Simply add a tag group named "TwxAnalyzerIgnores" to your project and inside that tag group use the title of the plugin as the name for the tag. Set this tag to an object and the results will not be generated for this.

I case an element should always be ignored, provide the tag 'all' inside the tag group.

