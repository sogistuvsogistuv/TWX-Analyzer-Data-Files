### Next Service Item Not Defined
Description:

The outgoing flow of a service/gateway/script/.. does not flow to the next service. This will result in a next service item not found exception once this flow is reached. This error will only be thrown during execution.

Supported item types:
Service, BPD

Example:

GSS NextServiceItemNotFound |
------------ |
The service ’GSS NextServiceItemNotFound’ has potential Next Service Not found at item: ’Switch - No Next Service Item’. |

### Unattached End Events
Description:

Unreachable end events should not be present in a service. They clutter the diagram and make using the service as a sub service more complicate, since it is not clear on that level which end
events are usable and which ones not.

Supported item types:
Service, BPD

Example:

NotWiredEndEvents Part2 |
------------ |
In the service ’NotWiredEndEvents Part2’ the item ’NotWiredEndEvents Part1’ has ’1’ unused end event. |

### Exception Code Mismatch

Description:

The list of errors that the sub service is able to throw does not contain the error code that the service expects. Each error end event of a sub service has a specific error code. If a service uses this sub service, it has to catch one of these specific error codes.

Supported item types:
Service

Example:

ExceptionCodeMismatch\_Part2 |
----------- |
The item 'ExceptionCodeMismatch\_Part1' has an Error Intermediate Event (catch specific) that's configured error code is: 'EXCEPTION\_CODE\_FEHLER', but the called SubService does not offer such a ExceptionEndEvent. The subServices error codes are: EXCEPTION\_CODE\_MISMATCH\_PART1\_FEHLER |

### Exception Type Mismatch

Description:

The error type of the service and its sub service have to match. Otherwise, the error can not be caught, which will result in a different error from the one that the service tries to catch.

Supported item types:
Service

Example:

ExceptionTypeMismatch\_Part2 |
------------ |
The item: ExceptionTypeMismatch\_Part1 has an Error Intermediate Event (catch specific) that's error mapping is different from the called subService. Current classId cb6b5b0a-f62c-4531-900e-8933b262ddaa/12.db884a3c-c533-44b7-bb2d-47bec8ad4022 and the classId of the subService:12.ec20f773-9bc5-4d3b-a528-7f13793e09f8. |

### Switch Condition Not Implemented

Description:

Every outgoing path of a switch condition, except the default, needs an implementation. Otherwise, the execution creates an exception.

Supported item types:
Service

Example:

Switch Condition Not Implemented |
------------ |
The switch element with name Switch has an output lane that is implemented. |

### Service Not Correctly Attached

Description:

The service references a service that no longer exists or has been renamed. This can happen if a toolkit is removed or renamed.

Supported item types:
Service, UNDERCOVERAGENT, EPV, PARTICIPANT, CLASS, BPD

GSS\_ServiceNotCorrectlyAttached |
------------ |
The attached service could not be found at item: 'PS Get Task URL'. |

### Exception Event Is catch all

Description

Regular services should not catch all errors, since error handling should be handled in the topmost layer. Only proxies and processes should contain a catch all intermediate error events. According to the logging conventions, each service should only throw an error of type "isWebserviceException", which should be caught by the next layer and propagated this way. Since each layer adds its service name, the sequence of called services can be reconstructed that way. This helps in tracing back errors to the service itself by only looking at the error shown in the default error handler.

Supported item types:
Service

Example:

ServiceContainsCatchAll\_Part2 |
------------ |
The ErrorCode (IS EMPTY!!) of the items (item: ServiceContainsCatchAll\_Part1) Exception event is catch All. Exception should be named: SERVICE\_CONTAINS\_CATCH\_ALL\_PART2\_FEHLER |

### Resource Not Linked

Description:

Unlinked resource variables produces exceptions during runtime and are to be avoided!

Supported item types:
Service, BPD

Example:

UndefinedResourceVariable |
------------ |
Found a resource variable that is not linked at service 'UndefinedResourceVariable > tw.resource.Constants.processNotDefined' |

### Next Service Item Not Defined

Description:

The outgoing flow of a service/gateway/script/.. does not flow to the next service. This will result in a next service item not found exception once this flow is reached. This error will only be thrown during execution.

Supported item types:
Service, BPD

Example:

GSS\_NextServiceItemNotFound ||
------------ |
The service 'GSS\_NextServiceItemNotFound' has potential Next Service Not found at item: 'Switch - No Next Service Item'.

### Exception Type Mismatch

Description:

The error type of the service and its sub service have to match. Otherwise, the error can not be caught, which will result in a different error from the one that the service tries to catch.

Supported item types:
Service

Example:

ExceptionTypeMismatch\_Part2 |
------------ |
The item: ExceptionTypeMismatch\_Part1 has an Error Intermediate Event (catch specific) that's error mapping is different from the called subService. Current classId cb6b5b0a-f62c-4531-900e-8933b262ddaa/12.db884a3c-c533-44b7-bb2d-47bec8ad4022 and the classId of the subService: /12.ec20f773-9bc5-4d3b-a528-7f13793e09f8.

### Uncatched Exception

Description:

According to the logging conventions, errors thrown by sub services should be caught by the next layer and propagated up. Each service in this chain appends its service name so that the call sequence can be reconstructed. If one service breaks this chain, the traceability of errors is impacted.

Supported item types:
Service

Example:

UncatchedException\_Part2 |
------------ |
The SubService: UncatchedException\_Part1 has an Exception Event \[UNCATCHED\_EXCEPTION\_PART1\_FEHLER\], that is not catched.

### Unbound Error Variable

Description:

This means the exception handler has no variable bound to it. Therefore, it can not catch the exception from the attached service. This will result in a different error from the original one, making a deliberate error handling impossible.

Supported item types:
Service

Example:

UnboundErrorVariable\_Part2 |
------------ |
The Exception Object of the exception handler at item 'UnboundErrorVariable\_Part1' is empty.

### Unattached End Events

Description:

Unreachable end events should not be present in a service. They clutter the diagram and make using the service as a sub service more complicate, since it is not clear on that level which end events are usable and which ones not.

Supported item types:
Service, BPD

Example:

NotWiredEndEvents\_Part2} |
------------ |
In the service 'NotWiredEndEvents\_Part2' the item 'NotWiredEndEvents\_Part1' has '1' unused end event. |

### Undefined Resource Variable

Description:

A resource variable that has not been defined in the resource file is used. Resource variables have to be defined before they are used.

Supported item types:
Service, BPD

Example:

ResourceNotLinked |
------------ |
Found a resource variable (ResourceUnlinked.IamNotExisting) that is not defined at item 'Script:ResourceVar' in Path: '/item\{Script\}\[ResourceVar\]/twComponent/script' and resource : ResourceUnlinked. |

### Undefined Variable

Description:

A variable that has not been defined is used. The plugin does not recognize if variables are in a comment, it would be considered as dead code anyway. Please keep in mind, that in some cases the missing variable occurred as invisible background variables, especially if the item is connected to UCAs. You might not always see the attribute. Please keep in mind, that this plugin, at this stage does only support the first variable level.

Supported item types:
Service, BPD

Example:

NoEntryLoggingDebug\_Typos |
------------ |
Found a variable that is not defined at item 'tw.local.localLoggerName' in Path: NoEntryLoggingDebug\_Typos:

### UCA Condition Without 'return true'

Description:

In order to function correctly conditions of a UCA should usually return 'true'. This value is needed due to the logging in the condition tab (See good practices : [UCA logging](../../bestpractices/all.md)). If the last line does not return a true statement, there might be other reasons. But usually the line should contain: "true;".

Supported item types:
BPD

Example:

UcaBrokenBpd\_NoCorrelationMethodSelected |
------------ |
Missing return value 'true' at UCA condition in process UcaBrokenBpd_NoCorrelationMethodSelected of item: cancelWithEvent |

### Toolkit Conflict

Description:

Toolkit conflicts are to be avoided, it means there are at least two different versions of the same toolkit imported in your project.

Example:

OftenChangedToolkit |
------------ |
These toolkits or process apps import snapshots of the same project in multiple versions. |
V0.0.1_OCT used by the following snapshots: V02_ADT in AnotherDependencyToolkit |
V0.0.2_OCT used by the following snapshots: 120419_26_TWXBAPP in TwxAnalyzer Beispiel App |

### Class Name Duplicate

Description:

These conflicts may occur if you use service discovery from within the BAW Server. They also appear if two toolkits of
the same origin in different versions are imported in the toolkit hierarchie. Those duplicated objects will be listed. 
This plugin ignores duplicates deriving from system toolkits.

Example:

BusinessObjectSimilarty1 & BusinessObjectSimilarty1 |
------------ |
These two classes have very similar names that might lead to errors.The class names 'BusinessObjectSimilarty1' & 'BusinessObjectSimilarty1' are very similar. Please check if this is intended. The classIds:<br>for BusinessObjectSimilarty1 : '12.f51a9d5e-72f9-4136-94c8-65ab64d07b1b'<br>for BusinessObjectSimilarty1 : '12.51f90bd6-444a-4a98-94ba-b478e484e260'. |

### Exception handling setup error

Description: 

There are different ways to handle exception in BPDs. This is one possibility to handle those. Therefore, this plugin is a project specific approach.
Almost every element in a bpd which must catch exceptions from the called service or subprocess with a catch all, following 
a message send object, with a specific uca. The "Exception token" then waits at a message receive an intermediate event. 
If the event occurs the process is continued. This plugin checks if the catch element is configured correctly, 
checks the needed post assignments as well as correlation parameters. Basically every step of the exception setup.

The catch all element awaits a post assignment which can be configured in the plugin settings.

The sending intermediate event needs an uca as well as an identification variable as input variable.

The message receive event also needs an uca and a set correlation parameter.

![Exception handling setup error](../../pictures/exception_handling_setup_error.png)

If the setup is not correct the following messages might occur:

Message | Explanation |
------------ | ---- | 
Exceptions are not caught at element {%s}. | The element hat no catch boundary event at all. |
Element {%s} has no configured UCA. | The sender or receiver is missing an attached UCA. |
The post assignment of the catch all event of element {%s} seems to be incorrect. | The post assignment seems to be wrong. |
Catch event at element {%s} is missing the necessary post assignment. | The post assignment needs an assignment and a script call. Check the plugins settings page under : "Exception handling" |
The configured UCA at element {%s} has no mapping parameters. | The UCA expects one input parameter with a specific value. Check plugins setting at "Exception handling" -> "UCA parameter correlation name" |
Element {%s} has multiple catch all events. | There can only be one catch all |
Exceptions are not caught with \"catch all\" at element {%s}. Check if it is set to check specific. | The catch boundary event is not of type catch all. It might be a catch specific. |
Element {%s} is not of type UCA send. | After the catch all boundary event the flow needs to go to a intermediate message send event. | 
Element {%s} is not of type UCA receive. | After the intermediate message send event the flow needs to got to a intermediate message receive event. |
The correlation parameter of element {%s} value contains the wrong value. Expected value is: {%s} | The UCA expects a specific variable as the correlation parameter. |
