
### Switch Output Not Named

Description:

The output lanes of switch conditions are easily mixed and therefore implementation accidentally ends up in the wrong output. To show what lane flows to which item, the lines need an identifying name.

Supported item types:
Service

Example:

SwitchOutputNotNamed |
------------ |
The switch element with name Switch has an output lane that is not named. |

### Element With Default Name

Description:

When scripts and other items are inserted into the service or process diagram, they are named 'default/untitled/...'. This initial name should be changed in order to make the service more expressive.

Supported item types:
Service, BPD

Example:

ElementWithDefaultName_IS |
------------ |
Service contains an item of type: 'Script' that has 'Untitled' in the name. See service: 'ElementWithDefaultName_IS' --> : 'Untitled1'. |

### No Entry Logging

Description:

At the start of a service, trace information should be written to 'logger.finer'. According to the logging conventions, all input variables should be logged at this stage to 'logger.finer' and the first element in a service contains that log statement, the element must be named: 'start logging'.

Supported item types:
Service

Example:

ElementWithDefaultName_IS |
------------ |
The first item Untitled1 of the service seems to be no logging element. |

### No Entry Logging Debug

Description:

At the start of a service, debug information should be written to 'logger.debug'. According to the logging conventions, all input variables should be logged at this stage to 'logger.debug'. Example for a correct Entry Logging:
``` javascript
if(logger.isDebug(tw.local.localLoggerName)) {
    var logMessage = "InputWerte: "; 
    logMessage += "InputVariable1: " + tw.local.inputVariable1;
    logger.debug(logMessage,tw.local.localLoggerName,tw.local.serviceName);
}
```

Supported item types:
Service

Example:

NoEntryLoggingDebug_Typos |
------------ |
The first item start logging of the service seems to lack of debug.logging. |

### No Entry Logging Finer

Description:

At the start of a service, trace information should be provided. According to the logging conventions, all input variables should be logged at this stage to 'logger.finer'.

Supported item types:
Service

Example:

NoEntryLoggingFiner_Missing	|
------------ |
The first item start logging of the service is not properly logging. Use logger.finer(). |

### Switch Output Not Named

Description:

The output lanes of switch conditions are easily mixed and therefore implementation accidentally ends up in the wrong output. To show what line flows to which item, the lines need an identifying name.

Supported item types:
Service

Example:

SwitchOutputNotNamed |
------------ |
The switch element with name 'Switch' has an output lane that is not named. |

### Undocumented Default Variable

Description:

The purpose of default values for variables should be explained.

Supported item types:
Service, BPD

Example:

ProcessWithDefaultIssues |
------------ |
The service ProcessWithDefaultIssues has a variable 'varWithDefaultAndNoDescription' with a default value '"whereIsMyDescription?"' and no description. |

### Variable Documentation Error

Description:

Input and output variables of BPDs and services need documentation. If a variable is 
used for input and output, the input documentation is sufficient.

Supported item types:
Service, BPD

Example:

ProcessWithDefaultIssues |
------------ |
The input variable named "bpdOutputVariable" has no documentation. |

### Incorrect History Entry

Description:

According to good practices the editor of a service or BPD, should update the documentation with a hint of what has been changed.
For that the user shall insert a new line starting with a date.

Example : "dd.MM.yyyy - username - describing text".

Services or BPDs are ignored if they have a UUID as their name, which means they mostly are by the system generated elements. With this Finding, three different message may appear:
* The latest DATE (%s) from history-documentation and last edit DATE (%s) are not equal.
* The latest EDITOR (%s) from history-documentation and last change EDITOR (%s) are not equal.
* The last CHANGE DATE from history-documentation could not be found. Or the history listing is not yet started.

Supported item types:
Service, BPD

Examples:

GSS_SearchableReferenceUsage |
------------ |
The last CHANGE DATE from history-documentation could not be found. Or the history listing is not yet started. |

DecisionServiceSimple |
------|
The latest EDITOR (admin) from history-documentation and last change EDITOR (03.01.2021 - eh2setw - Do...) are not equal. |

ComplexHumanService_migrated |
------------ |
The latest DATE (20.01.2020) from history-documentation and last edit DATE (03.01.2021) are not equal. |
