### Exception End Event Name

Description:

Exception events must be named to identify the service where the exception occurred. They are named via splitting the service name at the upper letters, chaining each part in capital letters. These characters \"_\" or \"-\" are considered connectors, they are removed and the two connected strings are combined. Then finally adding _FEHLER to the string.

Supported item types:
Service

LowerLetterInExceptionEvent	|
------------ |
Please see item Fehler at Service LowerLetterInExceptionEvent. The Exception Eventname is LOWER_LETTER_IN_EXCEPTION_event_FEHLER, but should be LOWER_LETTER_IN_EXCEPTION_EVENT_FEHLER |

### Localization Resource As Default Value

Description:

Using localization resources at a default value may cause exceptions. When using this service the default must be overwritten or the same localization variable has to be included in the 'calling' service.

Supported item types:
Service, BPD

Example:

DefaultValueWithLocalization |
------------ |
The service DefaultValueWithLocalization uses a localization variable containTitleWithLocalization as default value 'tw.resource.SimpleLocalization.title' |

### Proxy Without Error Information Service

Description:

According to the logging conventions, errors thrown by sub services should be caught by the next layer and propagated up. The proxy is the topmost layer and should present an error message to the logged in user. This service is named 'ErrorInformationService' and should be present in every proxy. Errors thrown by the services should flow to this error handler, as well as errors that are caught by a catch all.

Supported item types:
Service

Example:

defaultCreateProxy |
------------ |	
The service: 'defaultCreateProxy' is a proxy service and might not be able to show exceptions to the user |

### Resource Not Available

Description:

There is a resource variable in the code that's resource file is not attached to the service. Using such resource will results in an error at runtime.

Supported item types:
Service, BPD

Example:

UndefinedResourceVariable	|
------------ |
Found a linked resource (with id: f35d8ae0-1e20-42d4-a3ce-0d93324c0c20/50.3db4cf89-08a4-46e1-8128-69a48db46cc1) that is not available in the process app. |

### Save Execution Context

Description:

A script in this service saves its data upon completion which can have a very big impact on performance. This is only useful in very few cases and often enabled by mistake.

Supported item types:
Service

Example:

SaveExecutionContext	|
------------ |
There is a Save Execution Context setting in service: 'SaveExecutionContext' --> : 'SaveExecutionContext_Item'. |

### UCA Input != Output Parameter

Description:

Input variables are not identical that may lead to a loss of data, cause the uca does send 'null' for uninitialized variables.

Supported item types:
UNDERCOVERAGENT

Example:

ConditionalLoggingWhereUsed_UCA	|
------------ |
Service contains an UCA service, that has different input and output variables. See: SetChange{ 'set' collection changes :
. 'name' added
. 'value' added } |

### UCA Missing Logging At Condition

Description:

The logging conventions require a logging statement at the uca's that receiving the message. This helps to identify when and where a UCA is received.

Supported item types:
BPD

Example:

UcaBrokenBpd_NoCorrelationMethodSelected	|
------------ |
Missing condition logging at UCA in process UcaBrokenBpd_NoCorrelationMethodSelected of item: cancelWithEvent |

### UCA Targeting Snapshot

Description:

The UCA is missing a setting. This UCA is broadcasted into every snapshot and not limited to the one that is currently executed. This might result in unforeseen errors.

Supported item types:
Service

Example:

UcaNotTargetingSnapshotSender	|
------------ |
The UCA NotTargetingSnapshot is missing the 'target snapshot' setting in the implementation tab. |

### Unimplemented Service

Description:

The service has no implementation at all. Services like these are often used during early phases in a project to outline the overall process but should not be present in production code.

Supported item types:
Service

Example:

TestAjaxService	|
------------ |
The service 'TestAjaxService' is unimplemented and has no items. |

### Variable 'serviceName' Does Not Exist (needed prior to BAW 19)

Description:

According to the logging conventions, a variable with the name 'serviceName' has to be present in the service. This variable is used to add the name of the current service to the list of errors from the sub services. This creates a chain of service names, making it possible to trace errors to the service that caused it.

Supported item types:
Service

Example:

ClientSideHumanServiceTest|
------------ |
The service ClientSideHumanServiceTest has no local variable named servicename. |

### Variable 'serviceName' Without Default (needed prior to BAW 19)

Description:

According to the logging conventions, the variable 'serviceName' has to be named the same as the service itself. This should be done during the first script item in the process. An assignment of the services name to this variable is required. This variable is used to add the name of the current service to the list of errors from the sub services. This creates a chain of service names, making it possible to trace errors to the service that caused it.

Supported item types:
Service

Example:

VariableServiceNameWithoutDefault	|
------------ |
The service: 'VariableServiceNameWithoutDefault' has a local variable serviceName, that's not initialized in the first script item. |

### Variable 'serviceName' Has Wrong Name (needed prior to BAW 19)

Description:

According to the logging conventions, the variable 'serviceName' has to be named the same as the service itself. This variable is used to add the name of the current service to the list of errors from the sub services. This creates a chain of service names, making it possible to trace errors to the service that caused it.

Supported item types:
Service

Example:

UcaBrokenBpd_IntermediateService |
------------ |
The service: 'UcaBrokenBpd_IntermediateService' has a local variable serviceName, that's default (UsageOfLogDebug) is different of the services name. |

### Unused Variable

Description:

While developing there can be a whole lot of variable that are never used inside the service.
Those can be local variables of input/output variables. Neither are good coding styles.

Supported item types:
Service, BPD

Example:

UnusedVariable |
------------ |
The following variables are not used in this service: [tw.local.serviceException] |

### Step Name Differs From Service Name

Description:

When a step is named differently from the service where it is used as service in the item flow,
then finding errors that will become more difficult, since exceptions always mention the service
name and not the item name, where that service is used.

Supported item types:
Service

Example:

StepnameDiffersFromServiceName Part2 |
------------ |
The called SubService has a different name then the one set as step name. It should be named: ’StepnameDiffersFromServiceName Part1’ but is named: ’StepnameDiffersFromServiceName Part2’. |

### Proxy Without "Catch All"

Description:

In accordance with the logging conventions, errors should be handled in the topmost service. This means, that every proxy should catch individual errors from sub services and should also contain a catch all, to handle errors that are not propagated correctly.

Supported item types:
Service

Example:

TestServiceProxy |
------------ |
he service: 'TestServiceProxy' is a Proxy service and has no CatchAll Element. |

### Usage Of Old Log-Function

Description:

The log level for services when writing trace information should be 'finer'. Higher levels should be reserved for more critical warnings and errors.

Supported item types:
Service

Example:

UsageOfLogInfo |
------------ |
The service: 'UsageOfLogInfo' uses a log.info in item: 'item:Script:uses log.info' at element: service[UsageOfLogInfo]/item{Script}[uses log.info]/twComponent/script |

### Missing Element Documentation

Description:

The service or BPD is missing its documentation. According to good practices, services and BPDs are supposed to have an explaining text.

Supported item types:
Service, BPD

Example:

GSS_ModifyTaskImplementation |
------------ |
This element is missing its documentation |