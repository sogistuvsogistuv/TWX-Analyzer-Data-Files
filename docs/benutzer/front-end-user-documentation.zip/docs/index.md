# Welcome to the twx-Analyzer documentation

## Release Notes

Go to the [Release Notes](releasenotes/all.md) page to see the release notes of the twx-Analyzer.

---


## About the project
Code quality, adherence to guidelines and good practices are the major challenges of any BPM project. As the headcount of the project and lines of code grow, so do these challenges. Overall, application quality declines: Code gets harder to maintain, application performance suffers, defects become more difficult to find and deployments become more error-prone.

Existing code analysis tools often lack the flexibility to be tailored to individual coding guidelines. The twx-Analyzer contains a flexible plugin architecture and is developed considering, best practice rules alongside many projects.

## General description
The twx-Analyzer is a code governance and code analysis tool to help throughout the entire development cycle in IBM BPM projects. It thrives to solve some known shortcomings of the IBM Process Designer. But most important the analyzer focuses on helping to maintain development rules and good practices. It is also designed to help during refactoring tasks, which is one of the most important tasks in maintaining a clean code.

These tasks are accomplished by a plugin based system. Plugins can be created and customized for project or customer specific needs. All available plugins are listed [here](plugins/overview.md).

## Capabilities
Plugins create the analysis result and deliver so called 'findings', which indicate that some code or configuration disobeys a certain rule and therefor a developer should attend to and change it.But the twx-Analyzer also delivers tools and functionality for other tasks and questions, that come in handy when developing with IBM BPM. Details are at the components section.

Other capabilities are:

- **Snapshot comparison**: Compare two snapshots to see the differences between them.

- **Orphan Toolkit**: Find all toolkits that are not used in any snapshot.

- **Full text search**: Search for a specific string in all snapshots.

- **Ignore findings**: Permanently ignore findings from the result list.

- **CICD integration**: Use the twx-Analyzer in your CICD process.


You can use the twx-Analyzer with your cicd process. The twx-Analyzer provides a REST API for this purpose. The API is documented [here](installation/openapi_ci_v3.0.1.yaml).

Whenever you find a search function on top of a table, with the key combination "ctrl + shift + f" you put the cursor to the search and filter the entire table. Some tables also have a column specific filter function. Here you can find filter functions like "not equal", "not contains".

## License export 
Under Settings -> General you can download the license pdf file if your copy of the twx-Analyzer is not a demo version.