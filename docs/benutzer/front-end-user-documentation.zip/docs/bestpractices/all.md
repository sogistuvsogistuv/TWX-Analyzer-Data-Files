## Logging Convention
Usually projects start out with the BPM internal logging mechanism. But as your project grows, you might think about advanced logging mechanisms. There is for example java.util.logging which comes with IBM BPM. You can download the sample [logging file here](./logging.js.txt). The advantage of this approach is, that your log levels are controllable through the ISC Console. And you can create a more fine grained logging, which does not clutter your log file and reduces the performance impact on your system. There are other ways to do logging, you could extract your applications logging into different files. For more information please contact a representative of the twx Solutions GmbH.

### How it works (java.util.logging)
Every service needs two additional private variables although in BAW 19 it is only one. The first variable 'serviceName' contains the service name and is set at the start script. Then it needs a loggername, for that a variable called localLoggerName needs to be initialized with a logger name that is suitable for your project. These two variables are then used by the log command. Which would look similar to this:

``` javascript hl_lines="3 4"
tw.local.serviceName = "GeneralReusableService";
tw.local.localLoggerName = "service.global";
var logMessage = "This is my message to you..."
logger.info(logMessage, tw.local.serviceName, tw.local.localLoggerName);
```

<!--
The result in the log file would be:
`TODO`
Compared to the log.info output:
`TODO`
-->

### Start- and End-Logging 
It has been proven helpful to start every service with a script that creates an info-level log entry that the service just started. The same counts for an output logging. Before every end event item, a script that creates an end logging should be introduced. This helps to a) see which service chain was called and b) a rough estimation on how long it was executed.

#### Debug 
Additionally to the info logging at the beginning and end, you should insert a debug logging, that prints all input variables at the beginning and all output variables at the end.  

Here is how it should look like: 
``` javascript hl_lines="7"
tw.local.serviceName = "GeneralReusableService";
tw.local.localLoggerName = "service.global";
if(logger.isDebug(tw.local.localLoggerName)){
    var logMessage = "InputWerte: ";
    logMessage += "analysisId = " + tw.local.analysisId;
    logMessage += ", anotherVariable = " + tw.local.anotherVariable;
    logger.debug(logMessage, tw.local.localLoggerName, tw.local.serviceName);
}
```

A tool, that generates these input and output scripts is planed for release 2.0.2

### Changes with BAW 19

With BAW 19 the variable tw.local.serviceName is no longer needed. BPM now can call its own service name

### Old log.(info|debug)

With this convention the old logging mechanism is deprecated and there will be a warning if it is used.

### Plugins with this best practice
The following plugins belong to this best practice:

* [No Entry Logging](../plugins/details/badstyle-plugins.md#no-entry-logging)

* [No Entry Logging Finer](../plugins/details/badstyle-plugins.md#no-entry-logging-finer)

* [No Entry Logging Debug](../plugins/details/badstyle-plugins.md#no-entry-logging-debug)

* [Usage Of "log.info"](../plugins/details/warning-plugins.md#usage-of-loginfo")

## UCA good practices
UCAs can be tricky, especially if they are heavily used. It is easy to loose focus on which service triggers which UCA. And in production it is even important to be able to understand what has happend. These good practices shall help improving such situations.

### UCA Missing logging

UCAs are tricky to follow and hard to analyze. Therefore it is recommended to create a logging statement whenever a UCA is either received or send. For logging if one is sent, you should create a service inside the UCA instead of using a variable and have the service create a log statement. See below picture: ![figure 3](../pictures/uca_attached_service.png "Figure 3: Uca Attached Service"). And at the receiving end you should log the message in the condition section. Don't forget to add your condition or to add a true statement at the end like in figure 4. This final 'true;' statement is crucial in order to make this work. The corresponding plugin to this best practice is called "UCA Condition Without 'return true'". This is an example:
![figure_4](../pictures/uca_attached_service_receive.png "Figure 4: Uca Logging at a receiver")

Condition example:
``` javascript
logger.finer("UCA logging example: " + tw.message.ucaVariable + " empfangen.","service.global",tw.system.process.name);
true;
```

### Plugins with this best practice
The following plugins belong to this best practice:

* [UCA Condition Without 'return true'](../plugins/details/error-plugins.md#UCA Condition Without 'return true')

## Gateways
Gateways are great if you want to make your service flow readable and not hide all your decisions in script code. But a few things are necessary to keep in mind. Gateways should always be documented and the name should be a question. Often gateways have multiple outflows and because they are poorly named developers confused the flow and insert the wrong conditions into the flow. That is why every outgoing flow of a gateway should be named as if it would answer the question.

### Plugins with this best practice
* [Switch Condition Not Implemented](../plugins/details/error-plugins.md#switch-condition-not-implemented)

## Exception Event Naming
Exceptions are not evil! At some point you have to deal with exceptions and it turned out that exceptions should be named like the service of which they originate from. The twx-Analyzer has a built-in tool, that allows you to create the exception names. It is located under section develop -> service naming. You will find detailed description about this tooling under [ServiceNaming tool](../components/developer.md)

### Plugins with this best practice
* [Exception End Event Name](../plugins/details/warning-plugins.md#exception-end-event-name)

## Naming Good Practices
Consistend naming is important for many different reasons. Those are reducint the effort for reading and understanding the code, finding elements faster and during reviews arguing about more important issues then naming syntaxes saves time and effort.

### Plugins with this best practice
* [Step Name Differs From Service Name](../plugins/details/warning-plugins.md#step-name-differs-from-service-name)
* [Element With Default Name](../plugins/details/badstyle-plugins.md#element-with-default-name)
* [Switch Output Not Named](../plugins/details/badstyle-plugins.md#switch-output-not-named)

<!-- 
## Service naming
Name services where they are used with servicename at the beginning.
-->

